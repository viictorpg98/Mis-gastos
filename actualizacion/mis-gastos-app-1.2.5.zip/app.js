function norm(s){return String(s).normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/\s+/g," ").trim();}
var MON={ene:1,feb:2,mar:3,abr:4,may:5,jun:6,jul:7,ago:8,sep:9,sept:9,set:9,oct:10,nov:11,dic:12,enero:1,febrero:2,marzo:3,abril:4,mayo:5,junio:6,julio:7,agosto:8,septiembre:9,setiembre:9,octubre:10,noviembre:11,diciembre:12};
function parseAmt(l){
  if(!/\u20ac|eur/i.test(l)) return null;
  var m=/^([+\-\u2212]?)\s*(?:\u20ac\s*)?((?:\d{1,3}(?:\.\d{3})+|\d+),\d{2}|\d+\.\d{2})\s*(?:\u20ac|eur)?$/i.exec(l);
  if(!m) return null;
  var s=m[2]; s=s.indexOf(",")>-1?s.replace(/\./g,"").replace(",","."):s;
  var v=parseFloat(s); return m[1]==="+"?v:-v;
}
function parseDate(l,ref){
  var rl=/^(hoy|ayer|anteayer|antes de ayer)(?:\s*[-·•]\s*(.+))?$/i.exec(l);
  if(rl){var dd=new Date((ref||new Date()).getTime()),back=/^hoy/i.test(rl[1])?0:(/^ayer/i.test(rl[1])?1:2);dd.setDate(dd.getDate()-back);
    return {d:dd.getDate(),m:dd.getMonth()+1,y:dd.getFullYear(),s:(rl[2]||"").trim()};}
  var m=/^(\d{1,2})\/(\d{1,2})(?:\/(\d{4}|\d{2}))?(?:\s*[-\u00b7\u2022]\s*(.+))?$/.exec(l);
  if(m) return {d:+m[1],m:+m[2],y:m[3]?(m[3].length===2?2000+(+m[3]):+m[3]):0,s:(m[4]||"").trim()};
  m=/^(\d{1,2})\s+(?:de\s+)?([A-Za-z\u00c0-\u00ff]+)\.?(?:\s+(?:de\s+)?(\d{4}))?(?:\s*[-\u00b7\u2022]\s*(.+))?$/.exec(l);
  if(m){var mo=MON[norm(m[2])]; if(mo) return {d:+m[1],m:mo,y:m[3]?+m[3]:0,s:(m[4]||"").trim()};}
  return null;
}
function parsePaste(text,ref,yearOv){
  var lines=String(text).split(/\r?\n/).map(function(l){return l.trim();}).filter(Boolean);
  var out=[],seen={},skipped=0;
  for(var i=0;i<lines.length;i++){
    var dt=parseDate(lines[i],ref); if(!dt) continue;
    var nx=lines[i+1]!=null?parseAmt(lines[i+1]):null, v=null, name=null, eat=false;
    if(nx!==null){v=nx;name=lines[i-1];eat=true;}
    else{
      var pv=i>=2?parseAmt(lines[i-1]):null;
      if(pv!==null){v=pv;name=lines[i-2];} else name=lines[i-1];
    }
    if(name==null||parseDate(name)||parseAmt(name)!==null) continue;
    var s=dt.s,a=0;
    if(v!==null){a=v;if(eat)i++;}
    else if(!/verificaci/i.test(s)){skipped++;continue;}
    var y=dt.y||yearOv||(dt.m>ref.getMonth()+1?ref.getFullYear()-1:ref.getFullYear());
    var d=y+"-"+("0"+dt.m).slice(-2)+"-"+("0"+dt.d).slice(-2);
    var base=d+"|"+norm(name)+"|"+a.toFixed(2)+"|"+norm(s);
    seen[base]=(seen[base]||0)+1;
    out.push({k:base+"#"+seen[base],d:d,n:name,a:a,s:s});
  }
  out.skipped=skipped;
  return out;
}


(function(){
var $=function(i){return document.getElementById(i)};
var BASE=[
{id:"Salud y cuidado personal",n:"Salud y cuidado personal",c:"#E0607E",inc:0,kw:["farmacia","optica","barberia","peluquer","dentista","fisioterap"]},
{id:"Supermercado",n:"Supermercado",c:"#3FA66B",inc:0,kw:["mercadona","lidl","carrefour","aldi","alcampo","eroski","consum","condis","bonpreu","bon preu","hipercor","supermerc"]},
{id:"Restaurantes y bares",n:"Restaurantes y bares",c:"#F0A030",inc:0,kw:["restaur","pizz","burger","kebab","doner","mcdonald","telepizza","kfc","glovo","just eat","cafeteria","cerveceria","taqueria","sushi"]},
{id:"Ocio y deporte",n:"Ocio y deporte",c:"#4C8DF6",inc:0,kw:["padel","playtomic","cines","bowling","gimnas","teatro"]},
{id:"Compras",n:"Compras",c:"#8E6BD9",inc:0,kw:["amazon","zara","ikea","decathlon","el corte ingles","aliexpress","shein"]},
{id:"Transporte y coche",n:"Transporte y coche",c:"#27A9B8",inc:0,kw:["parking","aparcamiento","aparcaments","aparcar","gasolinera","benzinera","repsol","cepsa","renfe","uber","cabify","bolt"]},
{id:"Seguros y cuotas",n:"Seguros y cuotas",c:"#7C8A99",inc:0,kw:["seguro","mutua","mutualidad"]},
{id:"Suscripciones",n:"Suscripciones",c:"#C25BC0",inc:0,kw:["netflix","spotify","hbo","disney","youtube","apple"]},
{id:"Juegos y apuestas",n:"Juegos y apuestas",c:"#B8860B",inc:0,kw:["winamax","bet365","codere","apuestas"]},
{id:"Viajes",n:"Viajes",c:"#8BC34A",inc:0,kw:["booking","airbnb","ryanair","vueling","iberia"]},
{id:"Otros",n:"Otros",c:"#9AA5A8",inc:0,sys:1,kw:[]},
{id:"Bizum / transferencia enviada",n:"Bizum / transferencia enviada",c:"#E8845A",inc:0,sys:1,kw:[]},
{id:"Bizum / transferencia recibida",n:"Bizum / transferencia recibida",c:"#5DBB8A",inc:1,sys:1,kw:[]},
{id:"Entre cuentas",n:"Entre cuentas",c:"#7FA6B8",inc:0,sys:1,kw:[]},
{id:"Intereses",n:"Intereses",c:"#65B7A0",inc:1,sys:1,kw:["interes"]}];
var BASE_EV=["Entre cuentas","Intereses","Seguros y cuotas","Ocio y deporte","Juegos y apuestas","Supermercado","Restaurantes y bares","Transporte y coche","Salud y cuidado personal","Viajes","Suscripciones","Compras"];
var PAL=["#E0607E","#3FA66B","#F0A030","#4C8DF6","#8E6BD9","#27A9B8","#C25BC0","#B8860B","#8BC34A","#E8845A","#7C8A99","#5DBB8A","#D96C3F","#3D7EA6"];
var cats=[],CM={},CATS=[],INC={},EV=[],redir={},catsDoc=null,cdr=null;
function cl(x){return JSON.parse(JSON.stringify(x))}
function applyCats(){var list=(catsDoc&&catsDoc.list&&catsDoc.list.length)?catsDoc.list.map(cl):BASE.map(cl);
 BASE.forEach(function(b){if(b.sys&&!list.some(function(x){return x.id===b.id}))list.push(cl(b))});
 cats=list;CM={};INC={};CATS=[];redir=(catsDoc&&catsDoc.redir)||{};
 list.forEach(function(x){if(x.id==="Entre cuentas")x.inc=0;CM[x.id]=x;CATS.push(x.id);if(x.inc)INC[x.id]=1});
 var ord=[];list.forEach(function(x){if(x.custom)ord.push(x.id)});BASE_EV.forEach(function(id){if(CM[id]&&!CM[id].custom)ord.push(id)});
 EV=ord.map(function(id){return{id:id,kw:(CM[id].kw||[]).map(norm).filter(Boolean)}}).filter(function(x){return x.kw.length})}
function rid(id){var g=0;while(redir[id]&&g++<10)id=redir[id];return CM[id]?id:"Otros"}
function cname(id){return(CM[id]&&CM[id].n)||id}
function col(c){return(CM[c]&&CM[c].c)||"#9AA5A8"}
applyCats();
var MN=["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"];
var MS=["ene","feb","mar","abr","may","jun","jul","ago","sept","oct","nov","dic"],DS=["dom","lun","mar","mié","jue","vie","sáb"];
var coll=null,uid=null,months={},rules={},links={},shared={},excl={},ix={by:{},re:{},lk:{}},sel=null,filter="all",q="",editing=null,pick=null,pickE=null,sdr=null,smp=null,maxImg=0,meta={},hide=false,fday=null,fcat=null,ed=null,deleted={},cdel=null,mtype="out",pv=null,pvDel=null,ready=false,prefsDoc=null,pce=null,iaDoc=null,iaAvail=null,iaBusy=false,iaMsg="",iaWorking={},learnDoc=null,learn=null,appServer=false,appPhotos=false;
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})}
function eur(v,sg){if(hide)return"•••• €";var s=Math.abs(v).toFixed(2).replace(".",",").replace(/\B(?=(\d{3})+(?!\d))/g,".");var p=sg?(v>0?"+":v<0?"−":""):(v<0?"−":"");return p+s+" €"}
function isVoid(it){return /rechazad|verificaci/i.test(it.s||"")}
function isEx(it){return!!excl[it.k]}
function isOut(it){return isVoid(it)||!!excl[it.k]}
function kwExplicit(it){var n=norm(it.n);for(var i=0;i<EV.length;i++)for(var j=0;j<EV[i].kw.length;j++)if(n.indexOf(EV[i].kw[j])>-1)return EV[i].id;return null}
/* Palabras clave APRENDIDAS: se calculan solas a partir de los comercios ya categorizados (tus correcciones, categorias manuales, sugerencias de la IA
   y palabras clave). Una palabra se aprende cuando aparece en 2 o mas comercios distintos de la MISMA categoria y en ninguno de otra
   (y no esta ya entre las palabras clave). Como se recalculan, si corriges un comercio la palabra mal aprendida desaparece sola. Se pueden bloquear. */
function learnIdx(){if(learn)return learn;var M={},all=[],blk=(learnDoc&&learnDoc.block)||{},tm={},kws=[],by={};
 Object.keys(months).forEach(function(mo){months[mo].forEach(function(i){if(isBizLike(i))return;var n=norm(i.n),m=M[n]=M[n]||{n:i.n,c:null},c=rules[n]||i.c||kwExplicit(i)||iaMap()[n]||null;if(c)m.c=rid(c)})});
 EV.forEach(function(e){e.kw.forEach(function(k){all.push(k)})});
 Object.keys(M).forEach(function(n){htoks(M[n].n).forEach(function(t){if(t.length>=5)(tm[t]=tm[t]||[]).push(M[n])})});
 Object.keys(tm).forEach(function(t){var ms=tm[t].filter(function(m){return m.c});if(blk[t]||ms.length<2)return;if(all.some(function(k){return t.indexOf(k)>-1||k.indexOf(t)>-1}))return;
  var c=ms[0].c;if(!c||c==="Otros"||c==="Entre cuentas"||c==="Intereses"||/^Bizum \//.test(c))return;if(ms.some(function(m){return m.c!==c}))return;
  kws.push({t:t,c:c});(by[c]=by[c]||[]).push(t)});
 learn={kw:kws,by:by};return learn}
function kwAuto(it){var k=kwExplicit(it);if(k)return k;var L=learnIdx().kw;if(!L.length)return null;var tk=htoks(it.n);
 for(var i=0;i<L.length;i++)if(tk.indexOf(L[i].t)>-1)return rid(L[i].c);return null}
function isBizLike(it){return /bizum|completada|enviado/i.test(it.s||"")}
/* Categoria "por parecido": aprende de tus movimientos ya categorizados (correcciones a mano, categorias manuales y palabras clave).
   Compara las palabras del comercio nuevo con las de los que ya conoce y solo sugiere si hay evidencia clara; si no, queda en «Otros». Todo local. */
var HSTOP={};"de del la las el los les els lo en y i amb per con sin sl sa slu scp scoop ltd www com net org the and".split(" ").forEach(function(w){HSTOP[w]=1});
function htoks(n){var out=[],seen={};norm(n).replace(/[^a-z\s]/g," ").split(/\s+/).forEach(function(t){if(t.length>=3&&!HSTOP[t]&&!seen[t]&&!(learnDoc&&learnDoc.block&&learnDoc.block[t])){seen[t]=1;out.push(t)}});return out}
function htm(a,b){return a===b||(Math.min(a.length,b.length)>=5&&(a.indexOf(b)===0||b.indexOf(a)===0))}
function hpredict(name,train,th){var tk=htoks(name),score={};if(!tk.length)return null;
 tk.forEach(function(t,ti){var by={},tot=0;train.forEach(function(e){if(e.t.some(function(u){return htm(t,u)})){by[e.c]=(by[e.c]||0)+e.w;tot+=e.w}});
  if(!tot)return;var best=null,bw=0;Object.keys(by).forEach(function(c){if(by[c]>bw){bw=by[c];best=c}});
  score[best]=(score[best]||0)+(bw/tot)*Math.min(1,t.length/6)*(ti===0?1:0.5)*Math.min(1,tot/1.5)});
 var cs=Object.keys(score).sort(function(a,b){return score[b]-score[a]});if(!cs.length)return null;
 var s1=score[cs[0]],s2=cs[1]?score[cs[1]]:0;return(s1>=th&&s1>=1.4*s2)?cs[0]:null}
var hist=null;
function histIdx(){if(hist)return hist;var m={};
 function add(k,c,w){c=rid(c);if(!c||c==="Otros"||c==="Entre cuentas"||c==="Intereses"||/^Bizum \//.test(c))return;if(!m[k]||m[k].w<w)m[k]={c:c,w:w}}
 Object.keys(rules).forEach(function(k){add(k,rules[k],3)});Object.keys(iaMap()).forEach(function(k){add(k,iaMap()[k],1.2)});
 Object.keys(months).forEach(function(mo){months[mo].forEach(function(i){if(isBizLike(i))return;var k=norm(i.n);if(i.c)add(k,i.c,2);else{var c=kwAuto(i);if(c)add(k,c,1)}})});
 hist={train:Object.keys(m).map(function(k){return{c:m[k].c,w:m[k].w,t:htoks(k)}}).filter(function(e){return e.t.length}),memo:{}};return hist}
function histGuess(it){var h=histIdx(),k=norm(it.n);if(Object.prototype.hasOwnProperty.call(h.memo,k))return h.memo[k];return h.memo[k]=hpredict(it.n,h.train,0.7)}
function auto(it){var k=kwAuto(it);if(k)return k;
 if(isBizLike(it))return it.a>0?"Bizum / transferencia recibida":"Bizum / transferencia enviada";return histGuess(it)||aiGuess(it)||"Otros"}
function catOf(it){return rid(rules[norm(it.n)]||it.c||auto(it))}
function toast(t,act){var e=$("toast");e.textContent=t;if(act&&act.fn){var ub=document.createElement("button");ub.type="button";ub.className="tu";ub.textContent=act.label||"Deshacer";ub.addEventListener("click",function(){clearTimeout(toast.t);e.hidden=true;try{e.hidePopover()}catch(x){}act.fn()});e.appendChild(document.createTextNode(" "));e.appendChild(ub)}e.hidden=false;try{if(e.showPopover&&!e.matches(":popover-open"))e.showPopover()}catch(x){}clearTimeout(toast.t);toast.t=setTimeout(function(){e.hidden=true;try{e.hidePopover()}catch(x){}},act?9000:3500)}
function eff(it){return it.a<0?it.a+(ix.re[it.k]||0):it.a}
function lkE(v){return typeof v==="string"?v:(v&&v.e)}
function lkP(v){return v&&typeof v==="object"?(v.p||""):""}
function shr(k){var v=shared[k];if(v==null)return null;if(typeof v==="number")return{legacy:true,p:[]};return{legacy:false,p:(v.p||[]).map(function(x){return{n:x.n}})}}
function buildIndex(){hist=null;learn=null;var by={},re={},lk={},pp={},un={},ct={};Object.keys(months).forEach(function(m){months[m].forEach(function(i){by[i.k]=i})});
 Object.keys(links).forEach(function(r){var v=links[r],e=lkE(v);if(by[r]&&by[e]&&by[r].a>0&&by[e].a<0){re[e]=(re[e]||0)+by[r].a;lk[r]=1;ct[e]=(ct[e]||0)+1;var p=lkP(v),s=shr(e),ok=p&&s&&s.p.some(function(x){return norm(x.n)===norm(p)});
  if(ok){var q=norm(p);pp[e]=pp[e]||{};pp[e][q]=(pp[e][q]||0)+1}else un[e]=(un[e]||0)+1}});ix={by:by,re:re,lk:lk,pp:pp,un:un,ct:ct}}
function settle(k){var it=ix.by[k],s=shr(k);if(!it||!s)return null;
 if(!s.p.length)return{anon:true,people:[],pending:!(ix.ct&&ix.ct[k])};
 var U=(ix.un&&ix.un[k])||0,pe=s.p.map(function(x){return{n:x.n,paid:!!(ix.pp&&ix.pp[k]&&ix.pp[k][norm(x.n)])}});
 pe.forEach(function(x){if(!x.paid&&U>0){x.paid=true;U--}});
 return{anon:false,people:pe,pending:pe.some(function(x){return!x.paid})}}
function knownNames(){var s={};Object.keys(shared).forEach(function(k){var v=shr(k);if(v)v.p.forEach(function(x){s[norm(x.n)]=x.n})});
 Object.keys(ix.by).forEach(function(k){var i=ix.by[k];if(i.a>0&&i.n&&catOf(i)==="Bizum / transferencia recibida"){var f=i.n.split(/\s+/)[0];f=f.charAt(0).toUpperCase()+f.slice(1).toLowerCase();if(f.length>1&&!s[norm(f)])s[norm(f)]=f}});return s}
function fillPlist(){var s=knownNames();$("plist").innerHTML=Object.keys(s).sort().map(function(q){return'<option value="'+esc(s[q])+'">'}).join("")}
function dim(key){var p=key.split("-");return new Date(+p[0],+p[1],0).getDate()}
/* entra dinero = ingreso, sale = gasto; "Entre cuentas" no es un apartado aparte: se decide por el signo */
function isIn(it,c){return!!INC[c]||(c==="Entre cuentas"&&it.a>0)}
function stats(key){var items=months[key]||[],o={items:items,spend:{},total:0,inc:0,ints:0,rec:0,daily:[],dc:[]},n=dim(key);for(var i=0;i<n;i++){o.daily.push(0);o.dc.push({})}
 items.forEach(function(it){if(isOut(it)||ix.lk[it.k])return;var c=catOf(it),d=+it.d.slice(8);
  if(c==="Intereses")o.ints+=it.a;
  else if(isIn(it,c))o.inc+=it.a;
  else{var e=eff(it);o.spend[c]=(o.spend[c]||0)-e;o.total-=e;o.daily[d-1]-=e;o.dc[d-1][c]=(o.dc[d-1][c]||0)-e;if(it.a<0)o.rec+=(ix.re[it.k]||0)}});return o}
function keys(){return Object.keys(months).filter(function(k){return months[k].length}).sort()}
function prevKey(k){var p=k.split("-"),y=+p[0],m=+p[1]-1;if(m<1){m=12;y--}return y+"-"+("0"+m).slice(-2)}
function mlabel(k){var p=k.split("-");return MN[+p[1]-1]+" "+p[0]}
function dlabel(d){var x=new Date(+d.slice(0,4),+d.slice(5,7)-1,+d.slice(8));return DS[x.getDay()]+" "+x.getDate()+" "+MS[x.getMonth()]}
function renderNav(){var ks=keys().reverse();$("nav").innerHTML=ks.map(function(k){return'<button class="chip" data-m="'+k+'" aria-pressed="'+(k===sel)+'">'+mlabel(k)+(monthHasPend(k)?'<i class="dot wd" title="Tiene gastos por cobrar"></i>':"")+'</button>'}).join("");
 $("mt").textContent=sel?mlabel(sel):"Mis gastos";document.title=sel?"Gastos · "+mlabel(sel):"Mis gastos"}
function line(vals,W,H,P,mx){var n=vals.length,d="";vals.forEach(function(v,i){if(v==null)return;var x=P+i*(W-2*P)/Math.max(n-1,1),y=H-22-(v/mx)*(H-40);d+=(d?"L":"M")+x.toFixed(1)+" "+y.toFixed(1)});return d}
function axis(n,W,P,H){var s="";[1,10,20,n].forEach(function(d,i,a){if(a.indexOf(d)!==i||d>n)return;var x=P+(d-1)*(W-2*P)/Math.max(n-1,1);s+='<text x="'+x.toFixed(1)+'" y="'+(H-4)+'" text-anchor="middle" class="ax">'+d+'</text>'});return s}
function daysAgo(ms){var n=new Date(),a=new Date(n.getFullYear(),n.getMonth(),n.getDate()),b=new Date(ms),c=new Date(b.getFullYear(),b.getMonth(),b.getDate());return Math.round((a-c)/864e5)}
function ago(d){return d<=0?"hoy":d===1?"ayer":"hace "+d+" días"}
function renderSync(){var mx="";keys().forEach(function(k){months[k].forEach(function(i){if(!isVoid(i)&&i.d>mx)mx=i.d})});
 if(!mx){$("sync").innerHTML="";$("sync").className="sync";return}
 var dmx=daysAgo(new Date(+mx.slice(0,4),+mx.slice(5,7)-1,+mx.slice(8)).getTime()),dl=meta&&meta.last?daysAgo(meta.last):null,warn=(dl!=null?dl:dmx)>=7;
 $("sync").className="sync"+(warn?" warn":"");
 var dd=dl!=null?dl:dmx;$("sync").innerHTML=(warn?"<b>Hace "+dd+" días que no importas movimientos.</b> ":"")+"Último movimiento cargado: "+dlabel(mx)+" ("+ago(dmx)+")"+(dl!=null?" · importado "+ago(dl):"")+(warn?' <button class="btn go">Importar ahora</button>':"")}
/* ---------- ventanas, menus y paneles personalizables ---------- */
function openBox(id){closeMenus();var d=$(id);if(!d)return;if(id==="bakbox")bakRender();if(id==="bankbox")bankManInit();if(!d.open){if(tourOn&&d.show)d.show();else if(d.showModal)d.showModal();else d.setAttribute("open","")}
 if(id==="catbox")renderCatMan();if(id==="prefbox")renderPrefs();if(id==="iabox")renderIa()}
function closeBox(id){var d=$(id);if(d&&d.open){if(d.close)d.close();else d.removeAttribute("open")}}
function closeMenus(){["mPlus","mGear","mBank"].forEach(function(i){$(i).hidden=true});["bPlus","bGear","bBank"].forEach(function(i){$(i).setAttribute("aria-expanded","false")})}
function toggleMenu(bid,mid){var m=$(mid),was=!m.hidden;closeMenus();if(was)return;m.hidden=false;$(bid).setAttribute("aria-expanded","true");
 var r=$(bid).getBoundingClientRect(),w=m.offsetWidth;m.style.top=(r.bottom+6)+"px";m.style.left=Math.max(8,Math.min(r.right-w,window.innerWidth-w-8))+"px";var f=m.querySelector("button:not([disabled]),a[href]");if(f)f.focus()}
$("bPlus").addEventListener("click",function(e){e.stopPropagation();toggleMenu("bPlus","mPlus")});
$("bGear").addEventListener("click",function(e){e.stopPropagation();toggleMenu("bGear","mGear")});
$("bBank").addEventListener("click",function(e){e.stopPropagation();toggleMenu("bBank","mBank")});
document.addEventListener("click",function(e){var o=e.target.closest("[data-open]");if(o){openBox(o.dataset.open);return}
 var c=e.target.closest("[data-close]");if(c){var dg=c.closest("dialog");if(dg)closeBox(dg.id);return}
 if(!e.target.closest(".menu"))closeMenus();else if(e.target.closest(".menu button,.menu a"))closeMenus()});
document.addEventListener("keydown",function(e){if(e.key==="Escape"&&(!$("mPlus").hidden||!$("mGear").hidden||!$("mBank").hidden)){var pl=!$("mPlus").hidden,bk=!$("mBank").hidden;closeMenus();var b=$(bk?"bBank":pl?"bPlus":"bGear");if(b)b.focus()}});
window.addEventListener("scroll",closeMenus,{passive:true});window.addEventListener("resize",closeMenus);
document.querySelectorAll("dialog.sheet").forEach(function(d){var dn=false;d.addEventListener("mousedown",function(e){dn=e.target===d});d.addEventListener("click",function(e){if(!(e.target===d&&dn&&d.matches(":modal")))return;var r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)closeBox(d.id)})});
$("bResBtn").addEventListener("click",function(){$("bRes").click()});
var KDEF=[{id:"k_inc",n:"Ingresos (Bizums y transferencias)",d:"Dinero que te llega y no es de tus propias cuentas"},
 {id:"k_int",n:"Intereses",d:"Solo aparece si el mes tiene intereses"},
 {id:"k_rec",n:"Recuperado en gastos compartidos",d:"Solo aparece si te han devuelto dinero"},
 {id:"k_sav",n:"Ahorro del mes",d:"Ingresos menos gastos",on:0},
 {id:"k_proj",n:"Proyección a fin de mes",d:"A este ritmo, cuánto gastarás (solo en el mes en curso)",on:0}];
var PDEF=[{id:"p_pend",n:"Pendiente de cobrar",d:"Gastos compartidos que aún no te han pagado (solo aparece si hay)"},
 {id:"p_mes",n:"Gasto del mes",d:"Barras por día y categoría, y la línea de lo acumulado frente al mes anterior"},
 {id:"p_evo",n:"Evolución mensual",d:"Gasto e ingresos de cada mes, para ver cómo vas"},
 {id:"p_cat",n:"Por categoría",d:"Reparto del gasto del mes"},
 {id:"p_top",n:"Dónde más gastas",d:"Los comercios con más gasto"},
 {id:"p_fix",n:"Pagos fijos",d:"Cobros que se repiten cada mes (suscripciones, cuotas…), detectados solos"},
 {id:"p_mov",n:"Movimientos",d:"La lista para buscar, editar o eliminar"}];
/* Los dos graficos antiguos (acumulado y por dia) son ahora uno solo; los paneles nuevos se colocan antes de la lista de movimientos. */
function normPan(sp){sp=(sp||[]).filter(function(x){return x&&x.id});
 if(sp.some(function(x){return x.id==="p_acc"||x.id==="p_day"})){var o=[],ia=-1,on=0;sp.forEach(function(x){if(x.id==="p_acc"||x.id==="p_day"){if(x.on)on=1;if(ia<0){ia=o.length;o.push({id:"p_mes",on:0})}}else o.push(x)});o[ia].on=on;sp=o}
 ["p_evo","p_fix"].forEach(function(id){if(!sp.some(function(x){return x.id===id})){var im=-1;sp.forEach(function(x,i){if(id==="p_evo"?x.id==="p_mes":x.id==="p_mov")im=i});if(id==="p_evo"&&im>=0)im++;sp.splice(im<0?sp.length:im,0,{id:id,on:1})}});return sp}
function getPrefs(){var d=prefsDoc||{},cu=(d.custom||[]).filter(function(x){return x&&x.id}).map(function(x){return{id:String(x.id),n:String(x.n||""),c:(x.c||[]).slice()}});
 function mg(saved,defs){var out=[],seen={};(saved||[]).forEach(function(v){if(v&&!seen[v.id]&&defs.some(function(x){return x.id===v.id})){seen[v.id]=1;out.push({id:v.id,on:v.on?1:0})}});
  defs.forEach(function(x){if(!seen[x.id]){seen[x.id]=1;out.push({id:x.id,on:x.on===0?0:1})}});return out}
 return{kpi:mg(d.kpi,KDEF.concat(cu.map(function(x){return{id:x.id}}))),pan:mg(d.pan&&normPan(d.pan),PDEF),custom:cu,fixno:(d.fixno||[]).slice(0,200).map(String),bank:(d.bank||[]).filter(function(x){return x&&typeof x.u==="string"&&normUrl(x.u)}).slice(0,8).map(function(x){return{n:String(x.n||"").slice(0,40),u:normUrl(x.u)}})}}
async function savePrefs(P){if(!coll)return;try{await coll.doc("prefs").set({kpi:P.kpi,pan:P.pan,custom:P.custom,bank:P.bank||[],fixno:P.fixno||[]})}catch(e){toast("No se han podido guardar los ajustes")}}
function mutPrefs(fn){var P=getPrefs();fn(P);return savePrefs(P)}
/* Un panel que se oculta se desvanece y uno que se activa aparece con una pequeña animacion (la primera vez que se pinta, sin animacion). */
function panelShow(e,on){
 if(!e.dataset.pi){e.dataset.pi="1";e.hidden=!on;return}
 if(on){var was=e.hidden;e.classList.remove("pnl-out");e.hidden=false;if(was){e.classList.add("pnl-in");setTimeout(function(){e.classList.remove("pnl-in")},650)}}
 else if(!e.hidden&&!e.classList.contains("pnl-out")){e.classList.add("pnl-out");setTimeout(function(){if(e.classList.contains("pnl-out")){e.hidden=true;e.classList.remove("pnl-out")}},430)}}
function applyPrefs(){renderBankMenu();var P=getPrefs(),box=$("panels"),els=P.pan.map(function(p){return box.querySelector('[data-panel="'+p.id+'"]')}),cur=Array.prototype.slice.call(box.children);
 if(!(cur.length===els.length&&cur.every(function(e,i){return e===els[i]})))els.forEach(function(e){if(e)box.appendChild(e)});
 var vis=[];P.pan.forEach(function(p,i){var e=els[i];if(!e)return;panelShow(e,!!p.on);e.classList.remove("w7","w5","p6");if(p.on&&!(p.id==="p_pend"&&!e.firstChild))vis.push({id:p.id,e:e})});
 var run=[],FULL={p_pend:1,p_mov:1};function flush(){for(var jj=0;jj+1<run.length;jj+=2){run[jj].classList.add("p6");run[jj+1].classList.add("p6")}run=[]}
 vis.forEach(function(v){if(FULL[v.id])flush();else run.push(v.e)});flush()}
/* ===== Copias de seguridad: automaticas (carpeta copias), descargar y restaurar, todo en un solo sitio ===== */
function bakRender(){var box=$("bkauto");box.innerHTML='<h3 class="bkh">Copias automáticas</h3><p class="mut">Buscando copias…</p>';
 fetch("api/copias",{headers:{"X-Gastos":"1"},cache:"no-store"}).then(function(r){if(!r.ok)throw 0;return r.json()}).then(function(L){
  if(!L.length){box.innerHTML='<h3 class="bkh">Copias automáticas</h3><p class="mut">Todavía no hay ninguna. La app guarda una al día, la primera vez que guardas algo.</p>';return}
  box.innerHTML='<h3 class="bkh">Copias automáticas</h3><p class="mut">La app guarda sola una copia al día (las últimas 30) en la carpeta «copias», dentro de «datos». Si algo sale mal, vuelve a una de ellas. Antes de restaurar se guarda otra copia de lo que tienes ahora.</p><ul class="bklist">'+L.map(function(c){return'<li><span><b>'+esc(dlabel(c.fecha)+" "+c.fecha.slice(0,4))+"</b><small>"+(c.movs>=0?c.movs+" movimientos · ":"")+c.kb+' KB</small></span><button class="btn bkrest" data-n="'+esc(c.n)+'">Restaurar</button></li>'}).join("")+"</ul>"})
 .catch(function(){box.innerHTML='<h3 class="bkh">Copias automáticas</h3><p class="mut">Las copias automáticas solo existen cuando abres la app con «Mis gastos». Aquí abajo puedes descargar o restaurar una copia a mano.</p>'})}
$("bkauto").addEventListener("click",function(e){var b=e.target.closest(".bkrest");if(!b)return;
 if(!confirm("Esto reemplaza todos tus datos actuales por los de esa copia. Antes se guarda una copia de lo que tienes ahora. ¿Continuar?"))return;
 b.disabled=true;fetch("api/copias/restaurar",{method:"POST",headers:{"X-Gastos":"1","Content-Type":"application/json"},body:JSON.stringify({n:b.dataset.n})}).then(function(r){if(!r.ok)throw 0;toast("Copia restaurada");setTimeout(function(){location.reload()},700)}).catch(function(){b.disabled=false;toast("No se ha podido restaurar esa copia")})});
/* ===== Mi banco: enlaces a la web del banco de cada persona (solo se guarda la direccion) ===== */
function normUrl(u){u=String(u||"").trim();if(!u)return"";if(!/^[a-z][a-z0-9+.-]*:/i.test(u))u="https://"+u;try{var x=new URL(u);if(x.protocol!=="https:"&&x.protocol!=="http:")return"";if(!x.hostname||x.hostname.indexOf(".")<0)return"";return x.href}catch(e){return""}}
function bankHost(u){try{return new URL(u).hostname.replace(/^www\./,"")}catch(e){return u}}
function bankName(b){return b.n||bankHost(b.u)}
function bankColor(b){var h=0,t=bankName(b);for(var i=0;i<t.length;i++)h=(h*31+t.charCodeAt(i))%360;return"hsl("+h+" 48% 40%)"}
function renderBankMenu(){var P=getPrefs(),h="";
 P.bank.forEach(function(b){h+='<a role="menuitem" href="'+esc(b.u)+'" target="_blank" rel="noopener noreferrer"><span class="bk-i" style="background:'+bankColor(b)+'">'+esc(bankName(b).charAt(0).toUpperCase())+'</span><span class="bk-t">'+esc(bankName(b))+"<small>"+esc(bankHost(b.u))+"</small></span></a>"});
 if(!P.bank.length)h='<p class="mut bk-none">Todavía no has añadido tu banco. Guarda el enlace de su web y llegarás a ella desde aquí con un clic.</p>';
 h+='<hr><button role="menuitem" data-open="bankbox">'+(P.bank.length?"Editar mis bancos":"Añadir mi banco")+"</button>";$("mBank").innerHTML=h}
var bankDraft=[];
function bankManRender(){var h="";bankDraft.forEach(function(b,i){h+='<div class="bkrow" data-i="'+i+'"><input type="text" class="bkn" placeholder="Nombre (ej. Mi banco)" maxlength="40" value="'+esc(b.n)+'" aria-label="Nombre del banco"><input type="text" class="bku" placeholder="Enlace (ej. mibanco.es)" value="'+esc(b.u)+'" aria-label="Enlace de la web del banco" inputmode="url" autocapitalize="off" spellcheck="false"><button class="btn bkdel" title="Quitar este banco" aria-label="Quitar este banco">✕</button></div>'});
 if(!bankDraft.length)h='<p class="mut">Aún no hay ningún banco. Pulsa «＋ Añadir banco».</p>';$("bankman").innerHTML=h}
function bankManInit(){bankDraft=getPrefs().bank.map(function(b){return{n:b.n,u:b.u}});if(!bankDraft.length)bankDraft.push({n:"",u:""});$("bankmsg").textContent="";bankManRender()}
$("bankman").addEventListener("input",function(e){var r=e.target.closest(".bkrow");if(!r)return;var b=bankDraft[+r.dataset.i];if(!b)return;if(e.target.classList.contains("bkn"))b.n=e.target.value;else if(e.target.classList.contains("bku"))b.u=e.target.value;$("bankmsg").textContent=""});
$("bankman").addEventListener("click",function(e){var d=e.target.closest(".bkdel");if(!d)return;var r=d.closest(".bkrow");bankDraft.splice(+r.dataset.i,1);bankManRender()});
$("bkAdd").addEventListener("click",function(){if(bankDraft.length>=8){$("bankmsg").textContent="Puedes guardar hasta 8 bancos.";return}bankDraft.push({n:"",u:""});bankManRender();var l=$("bankman").querySelectorAll(".bkn");if(l.length)l[l.length-1].focus()});
$("bkSave").addEventListener("click",function(){var out=[],bad=null;
 bankDraft.forEach(function(b,i){if(bad!==null)return;var raw=String(b.u||"").trim();if(!raw&&!String(b.n||"").trim())return;var u=normUrl(raw);if(!u){bad=i;return}out.push({n:String(b.n||"").trim().slice(0,40),u:u})});
 if(bad!==null){$("bankmsg").textContent="El enlace del banco "+(bad+1)+" no es válido. Escribe su dirección web, por ejemplo mibanco.es";var r=$("bankman").querySelectorAll(".bku")[bad];if(r)r.focus();return}
 mutPrefs(function(P){P.bank=out});toast(out.length?"Bancos guardados":"Sin bancos guardados");closeBox("bankbox")});
function kcard(l,v,cls,sub){return'<div class="kpi'+(cls?" "+cls:"")+'"><small>'+esc(l)+"</small><b>"+v+"</b>"+(sub?"<em>"+esc(sub)+"</em>":"")+"</div>"}
function catSum(st,set){var t=0;st.items.forEach(function(it){if(isOut(it)||ix.lk[it.k])return;var c=catOf(it);if(set[c])t+=isIn(it,c)?it.a:-eff(it)});return t}
function kpisHtml(s,ps,cur,td,pk){var P=getPrefs(),h="";
 P.kpi.forEach(function(k){if(!k.on)return;var id=k.id;
  if(id==="k_inc")h+=kcard("Ingresos (Bizums y transferencias)",eur(s.inc),"in");
  else if(id==="k_int"){if(Math.abs(s.ints)>0.004)h+=kcard("Intereses",eur(s.ints))}
  else if(id==="k_rec"){if(s.rec>0.005)h+=kcard("Recuperado en gastos compartidos",eur(s.rec),"in")}
  else if(id==="k_sav"){var v=s.inc+s.ints-s.total;h+=kcard("Ahorro del mes",eur(v,true),v<0?"neg":"in","ingresos − gastos")}
  else if(id==="k_proj"){if(cur&&td>0)h+=kcard("Proyección a fin de mes",eur(s.total/td*dim(sel)),"","si sigues a este ritmo")}
  else{var cu=P.custom.filter(function(x){return x.id===id})[0];if(!cu)return;var set={},n=0;cu.c.forEach(function(c){if(CM[c]){set[c]=1;n++}});
   if(!n){h+=kcard(cu.n||"Panel sin nombre","—","","Elige categorías en Ajustes → Personalizar");return}
   var t=catSum(s,set),sub="";if(ps){var d=t-catSum(ps,set);sub=(Math.abs(d)<0.005?"Igual que":eur(Math.abs(d))+(d<0?" menos que":" más que"))+" "+MN[+pk.slice(5)-1]}
   h+=kcard(cu.n||"Panel sin nombre",eur(t),"",sub)}});
 return h?'<div class="kpis">'+h+"</div>":""}
function renderPrefs(){var P=getPrefs();
 function rows(list,defs,kind){return list.map(function(it,i){var cu=kind==="kpi"?P.custom.filter(function(x){return x.id===it.id})[0]:null,df=defs.filter(function(x){return x.id===it.id})[0]||{},nm=cu?(cu.n||"Panel sin nombre"):df.n,ds=cu?"Tarjeta propia: total de las categorías que elijas":(df.d||"");
  var r='<div class="prf" data-kind="'+kind+'" data-id="'+esc(it.id)+'"><label class="sw"><input type="checkbox" class="pon"'+(it.on?" checked":"")+'><span><b>'+esc(nm)+"</b>"+(ds?"<small>"+esc(ds)+"</small>":"")+'</span></label><span class="mv">'+(cu?'<button class="btn pced" aria-expanded="'+(pce===cu.id)+'">Editar</button>':"")+'<button class="btn up" aria-label="Subir"'+(i?"":" disabled")+'>↑︎</button><button class="btn dn" aria-label="Bajar"'+(i<list.length-1?"":" disabled")+">↓︎</button></span></div>";
  if(cu&&pce===cu.id)r+='<div class="pcedit" data-id="'+esc(cu.id)+'"><input type="text" class="pcn" value="'+esc(cu.n)+'" maxlength="40" placeholder="Nombre de la tarjeta" aria-label="Nombre de la tarjeta"><div class="mut">Suma de estas categorías:</div><div class="pcl">'+CATS.map(function(c){return'<label class="pcc"><input type="checkbox" class="pci" value="'+esc(c)+'"'+(cu.c.indexOf(c)>-1?" checked":"")+'><i class="dot" style="background:'+col(c)+'"></i>'+esc(cname(c))+"</label>"}).join("")+'</div><div class="prow"><button class="btn pcdel">Eliminar tarjeta</button><button class="btn pri pcok">Listo</button></div></div>';
  return r}).join("")}
 $("prefs").innerHTML='<p class="mut" style="margin:10px 0 0">Activa o desactiva lo que quieras ver y cámbialo de orden con las flechas. Se guarda solo y se aplica al instante. Lo que ocultes no se borra: sigue contando igual en los totales.</p>'+
  '<h3>Tarjetas de resumen</h3>'+rows(P.kpi,KDEF,"kpi")+'<div class="prow" style="margin-top:8px"><button class="btn" id="pcadd">＋ Tarjeta con mis categorías</button></div>'+
  '<h3>Paneles</h3>'+rows(P.pan,PDEF,"pan")+'<div class="prow" style="margin-top:14px"><button class="btn" id="pcreset">Restablecer valores originales</button></div>'}
$("prefs").addEventListener("change",function(e){var t=e.target,r=t.closest(".prf"),ed=t.closest(".pcedit");
 if(r&&t.classList.contains("pon")){var kd=r.dataset.kind,id=r.dataset.id;mutPrefs(function(P){var it=P[kd].filter(function(x){return x.id===id})[0];if(it)it.on=t.checked?1:0})}
 else if(ed&&t.classList.contains("pcn")){var id2=ed.dataset.id,nv=t.value.trim()||"Mi tarjeta";mutPrefs(function(P){var c=P.custom.filter(function(x){return x.id===id2})[0];if(c)c.n=nv})}
 else if(ed&&t.classList.contains("pci")){var id3=ed.dataset.id,sel2=Array.prototype.map.call(ed.querySelectorAll(".pci:checked"),function(x){return x.value});mutPrefs(function(P){var c=P.custom.filter(function(x){return x.id===id3})[0];if(c)c.c=sel2})}});
$("prefs").addEventListener("click",function(e){var b=e.target.closest("button");if(!b)return;var r=b.closest(".prf"),ed=b.closest(".pcedit");
 if(r&&(b.classList.contains("up")||b.classList.contains("dn"))){var kd=r.dataset.kind,id=r.dataset.id,dir=b.classList.contains("up")?-1:1;mutPrefs(function(P){var l=P[kd],i=l.findIndex(function(x){return x.id===id}),j=i+dir;if(i<0||j<0||j>=l.length)return;var tmp=l[i];l[i]=l[j];l[j]=tmp})}
 else if(r&&b.classList.contains("pced")){pce=pce===r.dataset.id?null:r.dataset.id;renderPrefs()}
 else if(b.id==="pcadd"){var nid="u-"+Math.random().toString(36).slice(2,8);pce=nid;mutPrefs(function(P){P.custom.push({id:nid,n:"Mi tarjeta",c:[]});P.kpi.push({id:nid,on:1})})}
 else if(ed&&b.classList.contains("pcok")){pce=null;renderPrefs()}
 else if(ed&&b.classList.contains("pcdel")){if(!confirm("¿Eliminar esta tarjeta?"))return;var id4=ed.dataset.id;pce=null;mutPrefs(function(P){P.custom=P.custom.filter(function(x){return x.id!==id4});P.kpi=P.kpi.filter(function(x){return x.id!==id4})})}
 else if(b.id==="pcreset"){if(!confirm("Se mostrarán otra vez los paneles originales y se borrarán tus tarjetas propias. ¿Continuar?"))return;pce=null;savePrefs({kpi:[],pan:[],custom:[]})}});
/* ---------- categorias sugeridas por IA (Claude Code de este ordenador; opcional) ---------- */
function iaMap(){return(iaDoc&&iaDoc.map)||{}}
function iaNone(){return(iaDoc&&iaDoc.none)||{}}
function aiGuess(it){var c=iaMap()[norm(it.n)],r=c?rid(c):null;return r&&r!=="Otros"?r:null}
function guessTxt(it){if(iaBusy&&iaWorking[norm(it.n)])return' · <span class="spin" aria-hidden="true"></span> categorizando con IA…';if(rules[norm(it.n)]||it.c||kwExplicit(it)||isBizLike(it))return"";if(kwAuto(it))return" · sugerida";return histGuess(it)?" · sugerida":(aiGuess(it)?" · sugerida por IA":"")}
function iaName(n){return String(n).split(/\s+/).join(" ").slice(0,120)}
function iaPending(){var seen={},out=[],mp=iaMap(),nn=iaNone();
 Object.keys(months).forEach(function(m){months[m].forEach(function(it){if(it.a>=0||isVoid(it)||isBizLike(it))return;var k=norm(it.n);
  if(seen[k]||rules[k]||it.c||kwAuto(it)||histGuess(it)||mp[k]||nn[k])return;seen[k]=1;out.push({k:k,n:iaName(it.n)})})});return out}
function iaCats(){return cats.filter(function(x){return!x.sys&&!x.inc}).map(function(x){return{n:x.n,p:(x.kw||[]).slice(0,8)}})}
async function iaPost(body){var r=await fetch("api/ia/categorizar",{method:"POST",cache:"no-store",headers:{"Content-Type":"application/json","X-Gastos":"1"},body:JSON.stringify(body)}),j=null;
 try{j=await r.json()}catch(e){}if(!r.ok)throw new Error((j&&j.error)||"error "+r.status);return j}
function iaInit(server){appServer=!!server;var im=document.querySelector('#mGear [data-open="iabox"]');if(im)im.hidden=!server;
 if(!server){iaAvail={disponible:false,motivo:"abre la aplicación con el archivo «Iniciar» (necesita el servidor local)."};return}
 fetch("api/ia/estado",{cache:"no-store",headers:{"X-Gastos":"1"}}).then(function(r){return r.json()}).then(function(j){iaAvail=j;if($("iabox").open)renderIa()})
  .catch(function(){iaAvail={disponible:false,motivo:"no se ha podido consultar al servidor."}})}
async function iaSave(patch){var d={on:iaDoc&&iaDoc.on?1:0,map:Object.assign({},iaMap()),none:Object.assign({},iaNone())};Object.assign(d,patch);
 try{await coll.doc("ia").set(d)}catch(e){toast("No se han podido guardar los ajustes de IA")}}
async function iaRun(list,quiet){if(demoMode){toast("En la demostración no se consulta a la IA");return}if(iaBusy||!list.length||!iaAvail||!iaAvail.disponible)return;iaBusy=true;iaWorking={};list.forEach(function(x){iaWorking[x.k]=1});iaMsg="Consultando a Claude…";render();
 var cs=iaCats(),byN={};cats.forEach(function(x){byN[x.n]=x.id});
 var map=Object.assign({},iaMap()),none=Object.assign({},iaNone()),ok=0,err="";
 for(var i=0;i<list.length;i+=40){var ch=list.slice(i,i+40);iaMsg="Consultando a Claude… "+Math.min(i+40,list.length)+" de "+list.length;renderIa();
  try{var r=(await iaPost({comercios:ch.map(function(x){return x.n}),categorias:cs})).r||{};
   ch.forEach(function(x){var nm=r[x.n],id=nm&&nm!=="Otros"?byN[nm]:null;if(id){map[x.k]=id;ok++}else if(nm!==undefined)none[x.k]=1})}
  catch(e){err=e.message;break}}
 iaBusy=false;iaWorking={};
 iaMsg=err?"No se ha podido completar: "+err:"Listo: "+ok+(ok===1?" comercio categorizado":" comercios categorizados")+(list.length-ok?" y "+(list.length-ok)+" sin categoría clara.":".");
 if(ok||Object.keys(none).length>Object.keys(iaNone()).length)await iaSave({map:map,none:none});else render();
 toast(err?"IA: "+err:(ok?"IA: "+ok+(ok===1?" comercio categorizado":" comercios categorizados"):"IA: no he encontrado una categoría clara"))}
function iaStat(){var e=$("iastat");if(!e)return;if(iaBusy){var n=Object.keys(iaWorking).length;e.hidden=false;e.innerHTML='<span class="spin" aria-hidden="true"></span> Categorizando con IA… '+n+(n===1?" comercio":" comercios")}else{e.hidden=true;e.innerHTML=""}}
function iaAuto(){if(demoMode)return;if(iaDoc&&iaDoc.on&&iaAvail&&iaAvail.disponible&&!iaBusy){var l=iaPending();if(l.length)iaRun(l,true)}}
function renderIa(){iaStat();var b=$("iactl");if(!b)return;
 var h='<p class="mut" style="margin:10px 0 0">Los comercios que no se reconocen ni por palabras clave ni por parecido pueden enviarse a Claude (modelo Haiku) para que sugiera una categoría.</p><ul class="hl">'+
  '<li>Solo se envía el <b>nombre del comercio</b> y los nombres de tus categorías. Nunca importes, fechas ni cuentas.</li>'+
  '<li>Usa la sesión de <b>Claude Code de este ordenador</b>, es decir, el plan de quien ejecuta la aplicación. No hay claves guardadas en la carpeta: si compartes la app, cada persona gasta el suyo (y sin Claude Code, esta opción no funciona).</li>'+
  '<li>Cada sugerencia se guarda y no se vuelve a consultar. Sale marcada como «sugerida por IA» y, si la cambias, manda tu corrección.</li>'+
  '<li>Tope de seguridad: '+((iaAvail&&iaAvail.limite)||400)+' comercios al día.</li></ul>';
 if(!iaAvail)h+='<p class="mut">Comprobando…</p>';
 else if(!iaAvail.disponible)h+='<div class="banner info" style="margin:10px 0">No disponible: '+esc(iaAvail.motivo||"")+"</div>";
 else{var on=iaDoc&&iaDoc.on,pend=iaPending().length,nm=Object.keys(iaMap()).length,nn=Object.keys(iaNone()).length;
  h+='<div class="prf"><label class="sw"><input type="checkbox" id="iaon"'+(on?" checked":"")+'><span><b>Usar IA para categorizar</b><small>Se aplica sola tras importar movimientos nuevos</small></span></label></div>'+
   '<div class="prow" style="margin-top:10px"><button class="btn pri" id="iarun"'+((iaBusy||!pend)?" disabled":"")+">Categorizar ahora"+(pend?" ("+pend+")":"")+"</button>"+
   ((nm||nn)?'<button class="btn" id="iaclear"'+(iaBusy?" disabled":"")+">Olvidar lo que sugirió la IA ("+nm+")</button>":"")+"</div>"+
   '<p class="mut" style="margin-top:8px">'+esc(iaBusy||iaMsg?iaMsg:(pend?pend+(pend===1?" comercio sin categoría pendiente de consultar.":" comercios sin categoría pendientes de consultar."):"No hay comercios pendientes de categorizar."))+"</p>"}
 b.innerHTML=h}
$("iactl").addEventListener("change",function(e){if(e.target.id==="iaon")iaSave({on:e.target.checked?1:0})});
$("iactl").addEventListener("click",function(e){var b=e.target.closest("button");if(!b)return;
 if(b.id==="iarun")iaRun(iaPending());
 else if(b.id==="iaclear"){if(!confirm("Se olvidarán las categorías que sugirió la IA (las que corregiste a mano se mantienen). ¿Continuar?"))return;iaMsg="";iaSave({map:{},none:{}})}});
function learnedHtml(id){var l=(learnIdx().by[id]||[]);if(!l.length)return"";return'<div class="lrn"><span>Aprendidas:</span>'+l.map(function(t){return'<button class="lk" data-t="'+esc(t)+'" title="Quitar esta palabra aprendida">'+esc(t)+" ✕</button>"}).join("")+"</div>"}
async function setLearnBlock(t,on){var b=Object.assign({},(learnDoc&&learnDoc.block)||{});if(on)b[t]=1;else delete b[t];if(t==null)b={};
 try{await coll.doc("learn").set({block:b});if($("catbox").open)renderCatMan()}catch(e){toast("No se ha podido guardar")}}
$("catman").addEventListener("click",function(e){var k=e.target.closest(".lk");if(k){var t=k.dataset.t;k.remove();setLearnBlock(t,true);return}
 if(e.target.id==="lkres"){setLearnBlock(null,false)}});
/* ---------- guia paso a paso + modo demostracion (datos inventados que no se guardan) ---------- */
var demoMode=false,demoApi={start:null,end:null},tourOn=false,tourI=0,tourInfo=null,tourOffered=false,tourHl=[];
function demoDocs(){
 var now=new Date(),y=now.getFullYear(),m=now.getMonth();
 function mo(off){var d=new Date(y,m-off,1);return{y:d.getFullYear(),m:d.getMonth()+1}}
 var A=mo(1),B=mo(2),C=mo(3),docs={},shared={},links={};
 function ds(M,day){return M.y+"-"+("0"+M.m).slice(-2)+"-"+("0"+day).slice(-2)}
 function add(M,day,n,a,s){var d=ds(M,day),k=d+"|"+norm(n)+"|"+a.toFixed(2)+"|"+norm(s||"")+"#1",it={k:k,d:d,n:n,a:a,s:s||""},id="m-"+d.slice(0,7);(docs[id]=docs[id]||{items:[]}).items.push(it);return it}
 add(A,1,"Mercadona",-42.18);add(A,2,"Cafetería Central",-3.2);add(A,3,"Netflix",-12.99);add(A,3,"Spotify",-10.99);add(A,4,"Repsol Gasolinera",-48);
 add(A,5,"Farmacia Santa Ana",-14.35);add(A,6,"Padel Club Norte",-18);add(A,7,"Amazon",-27.9);
 var rest=add(A,8,"Restaurante El Rincón",-64.8),biz=add(A,9,"Lucía Fernández",32.4,"Bizum");
 add(A,10,"Lidl",-31.76);add(A,11,"Panadería Casa Pepe",-3.6);add(A,12,"Peluquería Estilo Marta",-22);add(A,13,"Parking Plaza Mayor",-4.5);
 var piz=add(A,14,"Pizzería Napoli",-48);
 add(A,15,"Cines Aurora",-16.5);add(A,16,"Zara",-39.95);
 var tal=add(A,17,"Taller Hnos. Ruiz",-86.5),cena=add(A,19,"Cena Sushi Kyoto",-56);
 add(A,18,"Mercadona",-27.4);add(A,19,"Cafetería Central",-2.8);add(A,20,"Seguro Hogar",-34.2);add(A,21,"Marta Ruiz",15,"Bizum");add(A,22,"Booking",-120);
 add(A,23,"Intereses cuenta",0.84);var tra=add(A,24,"Traspaso cuenta ahorro",-300,"Enviado");var car=add(A,25,"Carlos Gil",60,"Bizum");
 add(A,26,"Gimnasio Fitness Sol",-29.9,"Rechazada");add(A,27,"Mercadona",-38.05);add(A,28,"Cafetería Central",-3.2);
 add(B,2,"Mercadona",-35.1);add(B,3,"Netflix",-12.99);add(B,3,"Spotify",-10.99);add(B,6,"Repsol Gasolinera",-52);add(B,9,"Lidl",-28.4);
 add(B,12,"Restaurante El Rincón",-41.5);add(B,13,"Cafetería Central",-3.2);add(B,15,"Amazon",-19.99);add(B,18,"Farmacia Santa Ana",-8.9);
 add(B,20,"Cines Aurora",-14);add(B,20,"Seguro Hogar",-34.2);add(B,25,"Carlos Gil",45,"Bizum");add(B,28,"Intereses cuenta",0.79);
 add(C,2,"Mercadona",-30.5);add(C,3,"Netflix",-12.99);add(C,3,"Spotify",-10.99);add(C,10,"Repsol Gasolinera",-45);add(C,14,"Lidl",-22.1);add(C,20,"Seguro Hogar",-34.2);add(C,24,"Cafetería Central",-3.2);
 Object.keys(docs).forEach(function(id){docs[id].items.sort(function(a,b){return a.d<b.d?1:a.d>b.d?-1:0})});
 shared[rest.k]={p:[{n:"Lucía"}]};shared[piz.k]={p:[{n:"Pablo"}]};links[biz.k]={e:rest.k,p:"Lucía"};
 docs.rules={map:{"panaderia casa pepe":"Supermercado","traspaso cuenta ahorro":"Entre cuentas"}};docs.shared={map:shared};docs.links={map:links};docs.meta={last:Date.now()};
 var dm=A.m,sample="Panadería La Espiga\n27/"+dm+"\n4,20 €\n\nCafetería Brasil\n27/"+dm+"\n2,60 €\n\nMarta Ruiz\n26/"+dm+" - Bizum\n+10,00 €";
 return{docs:docs,info:{selKey:ds(A,1).slice(0,7),sample:sample,taller:tal.k,tras:tra.k,cena:cena.k,bizum:car.k,pend:piz.k,mon:dm}}}
var tourSels=[],tourCtx=[],tourStSels=[],tourStCtx=[],tourS=0,tourTimer=null,tourBusy=false,tourOk="",tourTok=0,tourHide0=false,tourRaf=0,tourAnimating=false,tourAnimTok=0,tourCap="",tourAnimWhy="",tourBefore=null;
/* ===== Foco: la pantalla se aclara solo donde toca; el resto se atenua y no responde a clics ===== */
function tourRects(sels){var out=[];sels.forEach(function(q){var e=document.querySelector(q);if(e){var r=e.getBoundingClientRect();if(r.width>0&&r.height>0)out.push({l:r.left,t:r.top,r:r.right,b:r.bottom})}});return out}
function tourPad(r,p){return{l:Math.max(2,r.l-p),t:Math.max(2,r.t-p),r:Math.min(window.innerWidth-2,r.r+p),b:Math.min(window.innerHeight-2,r.b+p)}}
function tourMerge(rs){var m=true,i,j,a,b;while(m){m=false;for(i=0;i<rs.length&&!m;i++)for(j=i+1;j<rs.length&&!m;j++){a=rs[i];b=rs[j];
  if(a.l<=b.r&&b.l<=a.r&&a.t<=b.b&&b.t<=a.b){rs[i]={l:Math.min(a.l,b.l),t:Math.min(a.t,b.t),r:Math.max(a.r,b.r),b:Math.max(a.b,b.b)};rs.splice(j,1);m=true}}}return rs}
var tourLoopRaf=0,tourClipLast="",tourRingLast="";
function tourSpot(){var dim=$("tourdim"),ring=$("tourring");if(!dim||!ring)return;
 if(!tourOn){dim.hidden=true;ring.hidden=true;return}
 var st=TOUR[tourI],sg=tourStageObj(),W=window.innerWidth,H=window.innerHeight,tg=tourRects(tourSels),cx=tourRects(tourCtx);
 /* Solo se oscurece la pantalla cuando la persona tiene que pulsar algo; en animaciones, lecturas y avisos de "Hecho" se ve normal. */
 var wait=!tourAnimating&&!tourOk&&!st.intro&&sg&&!sg.info&&(tg.length||cx.length);
 if(wait){var holes=tourMerge(tg.concat(cx).map(function(r){return tourPad(r,7)})),path="M0 0H"+W+"V"+H+"H0Z";
  holes.forEach(function(h){path+="M"+h.l+" "+h.t+"H"+h.r+"V"+h.b+"H"+h.l+"Z"});
  if(path!==tourClipLast){dim.style.clipPath='path(evenodd,"'+path+'")';tourClipLast=path}dim.hidden=false}
 else dim.hidden=true;
 /* Los recuadros se recalculan en cada fotograma: desaparecen al instante si su elemento ya no esta y siguen al elemento si se mueve. */
 if(tourOk||st.intro||!tg.length){ring.hidden=true;return}
 var q=tg.map(function(r){return tourPad(r,4)}),sig=q.map(function(r){return[r.l,r.t,r.r,r.b].map(Math.round).join(",")}).join("|");
 ring.hidden=false;if(sig===tourRingLast)return;tourRingLast=sig;
 while(ring.children.length<q.length){var i=document.createElement("i");i.className="tr";ring.appendChild(i)}
 while(ring.children.length>q.length)ring.removeChild(ring.lastChild);
 q.forEach(function(r,k){var e=ring.children[k];e.style.left=r.l+"px";e.style.top=r.t+"px";e.style.width=(r.r-r.l)+"px";e.style.height=(r.b-r.t)+"px"})}
function tourLoop(){if(!tourOn){tourLoopRaf=0;return}tourSpot();tourLoopRaf=requestAnimationFrame(tourLoop)}
function tourSpotSoon(){if(tourRaf)return;tourRaf=requestAnimationFrame(function(){tourRaf=0;tourSpot()})}
window.addEventListener("scroll",tourSpotSoon,true);window.addEventListener("resize",tourSpotSoon);
function tourNudge(){var t=$("tour");t.classList.remove("nudge");void t.offsetWidth;t.classList.add("nudge")}
$("tourdim").addEventListener("click",function(e){e.stopPropagation();tourNudge()});
function tourTargets(){var out=[];tourSels.forEach(function(s){var e=document.querySelector(s);if(e)out.push(e)});return out}
function tourVisible(e){var r=e.getBoundingClientRect(),th=parseInt(document.documentElement.style.getPropertyValue("--tourh")||"0",10)||0;return!(r.top<90||r.bottom>window.innerHeight-th-14)}
function tourReveal(e){if(!e||e.closest(".menu,#tour"))return;try{if(e.closest("dialog"))e.scrollIntoView({behavior:"auto",block:"nearest"});else if(!tourVisible(e))e.scrollIntoView({behavior:"auto",block:"center"})}catch(x){}}
function tourHighlight(sels,noscroll){tourSels=sels||[];if(!noscroll)tourReveal(tourTargets()[0]);tourSpot()}
function tourReHl(){if(tourOn&&(tourSels.length||tourCtx.length))tourSpot()}
function tourFocusRow(k,open){var it=ix.by[k];if(!it)return;sel=it.d.slice(0,7);q="";$("q").value="";fday=null;fcat=null;ed=null;pick=null;pickE=null;cdel=null;setFilter("all");editing=open?k:null;render()}
function tourRow(k){return'.row[data-k="'+k+'"]'}
function tourSavedCount(i){return(months[i.selKey]||[]).length}
/* ===== Cambios visibles: se resalta lo que ha cambiado y el total "cuenta" hasta su nuevo valor ===== */
function tourSnap(){var o={big:(document.querySelector(".big")||{}).textContent,kpis:[],rows:{},pend:$("pend")?$("pend").innerText:""};
 document.querySelectorAll(".kpi").forEach(function(e){o.kpis.push(e.innerText)});
 document.querySelectorAll("#rows .row").forEach(function(e){var n=e.querySelector(".n"),a=e.querySelector(".a");o.rows[e.dataset.k]=(n?n.innerText:"")+"|"+(a?a.innerText:"")});
 return o}
function tourNum(t){t=String(t||"");if(/•/.test(t))return null;var m=t.replace(/[−–]/g,"-").replace(/[^\d,.\-]/g,"");if(!/\d/.test(m))return null;m=m.replace(/\./g,"").replace(",",".");var v=parseFloat(m);return isNaN(v)?null:v}
function tourRoll(el,from,to){var t0=performance.now();function f(t){var k=Math.min(1,(t-t0)/1100),e=1-Math.pow(1-k,3);el.textContent=eur(from+(to-from)*e);if(k<1)requestAnimationFrame(f)}requestAnimationFrame(f)}
function tourFlash(els){els.forEach(function(e){e.classList.remove("tour-flash");void e.offsetWidth;e.classList.add("tour-flash");setTimeout(function(){e.classList.remove("tour-flash")},2300)});
 var f=els.filter(function(e){return e.closest("#rows")})[0];if(f&&!tourVisible(f)){try{f.scrollIntoView({behavior:"auto",block:"center"})}catch(x){}}}
function tourDiff(b){if(!b)return;var els=[],big=document.querySelector(".big");
 if(big&&b.big!==undefined&&b.big!==big.textContent){var x=tourNum(b.big),y=tourNum(big.textContent);if(x!==null&&y!==null&&x!==y){tourRoll(big,x,y);els.push(big)}}
 document.querySelectorAll(".kpi").forEach(function(e){if(b.kpis.indexOf(e.innerText)<0)els.push(e)});
 document.querySelectorAll("#rows .row").forEach(function(e){var n=e.querySelector(".n"),a=e.querySelector(".a"),s=(n?n.innerText:"")+"|"+(a?a.innerText:"");if(b.rows[e.dataset.k]!==s)els.push(e)});
 if($("pend")&&$("pend").firstElementChild&&$("pend").innerText!==b.pend)els.push($("pend").firstElementChild);
 if(els.length)tourFlash(els)}
/* ===== Cursor animado: se mueve por la pantalla y pulsa de verdad, para ver el flujo ===== */
function tw(ms){return new Promise(function(r){setTimeout(r,ms)})}
async function twaitEl(sel,ms){var t0=Date.now(),e,r;while(Date.now()-t0<ms){e=document.querySelector(sel);if(e){r=e.getBoundingClientRect();if(r.width>0&&r.height>0)return e}await tw(80)}return null}
function tcurSet(x,y){$("tourcur").style.transform="translate("+x+"px,"+y+"px)"}
function tcurShow(){var c=$("tourcur");if(c.hidden){c.hidden=false;c.style.transition="none";tcurSet(window.innerWidth-90,window.innerHeight-150);void c.offsetWidth;c.style.transition=""}}
async function tcurTo(sel,tk,ms,also){var e=await twaitEl(sel,ms||1800);if(!e||tk!==tourAnimTok)return null;tourReveal(e);await tw(60);
 tourSels=[sel].concat(also||[]);tourCtx=[];tourSpot();tcurShow();var r=e.getBoundingClientRect();tcurSet(Math.round(r.left+Math.min(r.width/2,80)),Math.round(r.top+r.height/2));await tw(1250);return tk===tourAnimTok?e:null}
async function tcurClick(e,tk,noop){await tw(450);var c=$("tourcur");c.classList.remove("click");void c.offsetWidth;c.classList.add("click");await tw(320);if(tk!==tourAnimTok)return;if(!noop)e.click();await tw(950);tourSpot()}
async function tcurType(sel,text,tk){var e=await tcurTo(sel,tk);if(!e)return;await tcurClick(e,tk,true);e.focus();for(var i=0;i<text.length;i++){if(tk!==tourAnimTok)return;e.value+=text.charAt(i);e.dispatchEvent(new Event("input",{bubbles:true}));await tw(150)}await tw(700)}
/* El cursor va primero al texto de la tarjeta, lo subraya y da tiempo a leerlo; despues se hace la accion. */
async function tourRead(tk,first){var el=await twaitEl("#tour .tour-say",1200);if(!el||tk!==tourAnimTok)return;var len=el.innerText.length+(first?tourAnimWhy.length:0);
 tourSels=[];tourCtx=[];tourSpot();
 var u=el.querySelector(".tour-u");if(u){void u.offsetWidth;u.classList.add("on")}await tw(Math.min(7500,1700+len*38))}
async function tourPlay(script,tk){var first=true;for(var i=0;i<script.length;i++){var a=script[i],e;if(tk!==tourAnimTok)return false;
  if(a.cap!==undefined){tourCap=a.cap;renderTour();await tourRead(tk,first);first=false}
  if(a.click){e=await tcurTo(a.click,tk,a.opt?800:1800,a.also);if(e)await tcurClick(e,tk,a.noop)}
  else if(a.type)await tcurType(a.type,a.text,tk);
  else if(a.set){e=await tcurTo(a.set,tk);if(e){await tcurClick(e,tk,true);e.value=a.value;e.dispatchEvent(new Event("input",{bubbles:true}));await tw(900)}}
  else if(a.select){e=await tcurTo(a.select,tk);if(e){await tcurClick(e,tk,true);e.value=a.value;e.dispatchEvent(new Event("change",{bubbles:true}));await tw(1100)}}
  else if(a.hover)await tcurTo(a.hover,tk);
  else if(a.fn)await a.fn();
  tourSpot();await tw(a.wait!==undefined?a.wait:700)}
 return tk===tourAnimTok}
function tourAnimFinish(){tourAnimating=false;tourCap="";tourAnimWhy="";$("tourcur").hidden=true;$("tourshield").hidden=true}
async function tourAnimate(script,why){var tk=++tourAnimTok;tourAnimating=true;tourAnimWhy=why||"";$("tourshield").hidden=false;renderTour();var ok=await tourPlay(script,tk);if(tk===tourAnimTok)tourAnimFinish();return ok}
/* ===== Capturas de ejemplo para la demostracion de "subir una captura" ===== */
function tourShotFile(rows){return new Promise(function(res){var c=document.createElement("canvas");c.width=715;c.height=40+rows.length*96;var x=c.getContext("2d"),F="'Segoe UI',system-ui,Arial,sans-serif";
 x.fillStyle="#121212";x.fillRect(0,0,c.width,c.height);x.textBaseline="alphabetic";
 rows.forEach(function(r,i){var y=44+i*96;x.strokeStyle=r.inc?"#333":"#e8e8e8";x.lineWidth=3;x.beginPath();x.arc(46,y+18,13,0,6.3);x.stroke();
  x.fillStyle="#fff";x.font="700 17px "+F;x.textAlign="left";x.fillText(r.n,86,y+10);
  x.fillStyle="#a8a8a8";x.font="700 14px "+F;x.fillText(r.d,86,y+38);
  x.fillStyle="#fff";x.font="700 17px "+F;x.textAlign="right";x.fillText(r.a,669,y+26)});
 c.toBlob(function(b){res(new File([b],"captura-del-banco.png",{type:"image/png"}))},"image/png")})}
async function tourOcrDemo(i){var w=await tourShotFile([{n:"Panadería La Espiga",d:"27/"+i.mon,a:"4,20 €"},{n:"Cafetería Brasil",d:"27/"+i.mon,a:"2,60 €"},{n:"Marta Ruiz",d:"26/"+i.mon+" - Bizum",a:"+10,00 €",inc:1}]);
 var dt=new DataTransfer();dt.items.add(w);$("photof").files=dt.files;return w}
async function tourOcrWait(i){tourCtx=["#photomsg"];tourSpot();var t0=Date.now();
 while(Date.now()-t0<75000){var m=$("photomsg").textContent;if(/Leídos|No he reconocido|No se han podido/.test(m))break;await tw(300)}
 if(!/^3 movimientos/.test(($("prev").innerText||"").trim())){$("paste").value=i.sample;await review()}await tw(600)}
/* ===== Pasos de la guia ===== */
var TOUR=[
{t:"¡Hola! Vamos a practicar",intro:"<b>Mis gastos</b> te ayuda a ver en qué gastas tu dinero: importas los movimientos de tu banco y la app los ordena por categorías y te los muestra con gráficos.<br><br>Te voy a guiar paso a paso, <b>explicándote para qué sirve cada cosa</b>. Usaremos datos inventados: no tocan los tuyos y no se guarda nada.",next:"Empezar",skip:"Ahora no"},
{t:"Importa tus movimientos",start:function(i){sel=i.selKey;i.base=tourSavedCount(i);render()},
 play:function(i){return[{cap:"Para importar: pulsa «＋ Añadir»…",click:"#bPlus"},{cap:"…elige «Importar movimientos»…",click:'#mPlus [data-open="impbox"]'},{cap:"…y pega la lista que copias de tu banco.",fn:function(){$("paste").value=i.sample;tourFlash([$("paste")])},wait:1300}]},
 stages:[
 {say:"Pulsa «Revisar».",why:"«Revisar» lee los movimientos pegados y te enseña lo que ha entendido antes de guardar nada. Así entran tus gastos sin teclearlos.",ctx:["#paste"],hl:["#bRev"],enter:function(i){openBox("impbox");$("paste").value=i.sample;$("prev").innerHTML="";pv=null},demo:function(){return[{click:"#bRev"}]},done:function(){return!!(pv&&pv.length)},auto:function(){review()},redo:{cond:function(){return!$("impbox").open},to:0}},
 {say:"También puedes subir capturas de pantalla.",why:"En vez de copiar el texto, haces una captura de la lista de movimientos de tu banco (en Windows: Win + Mayús + S) y la pegas aquí con Ctrl + V, sin guardarla como archivo; también puedes subirla como archivo con «Leer fotos». La app lee el texto en tu ordenador. Revisa siempre los importes antes de guardar.",info:true,when:function(){return appPhotos},hl:["#photobox"],ok:"Ya sabes las formas: copiar el texto, pegar una captura con Ctrl + V o subirla como archivo. Usa la que te resulte más cómoda.",
  anim:function(i){if($("photoctl").hidden)return[{cap:"Para leer capturas, abre la app con «Iniciar-Windows.bat».",wait:2600}];
   return[{cap:"Haces la captura con Win + Mayús + S y la pegas aquí con Ctrl + V: se lee sola, sin guardar nada.",wait:3400},{cap:"Si ya la tienes como archivo, pulsas «Elegir archivos» y eliges la captura de tu banco…",click:"#photof",noop:true},{cap:"(Aquí usamos una captura de ejemplo.)",fn:function(){return tourOcrDemo(i)},wait:900},
    {cap:"…pulsas «Leer fotos»…",click:"#bPhoto"},{cap:"La app lee el texto de la imagen, en tu ordenador…",fn:function(){return tourOcrWait(i)}},{cap:"…y rellena el cuadro con lo que ha leído. Solo queda guardar.",wait:1800}]},
  redo:{cond:function(){return!$("impbox").open},to:0}},
 {say:"Pulsa «Guardar».",why:"Es seguro repetir: los movimientos que ya estaban se saltan solos, así que puedes importar listas que se solapan sin duplicar nada.",ctx:["#prev"],hl:["#bSave"],demo:function(){return[{click:"#bSave"}]},done:function(i){return tourSavedCount(i)>i.base},auto:function(){save()},ok:"Ya están en el mes. Fíjate: «La Espiga» salió como «sugerida», porque se parece a otra panadería que ya conocía.",redo:{cond:function(){return!$("impbox").open},to:0}}]},
{t:"Tu banco, a un clic",stages:[
 {say:"Guarda aquí la web de tu banco.",why:"Para no buscarla cada vez que vayas a traer movimientos, guardas su enlace en «🏦 Mi banco» y entras con un clic: se abre en otra pestaña y esta sigue esperando. Cada persona guarda los suyos, y solo se guarda la dirección (nunca usuario ni contraseña).",info:true,hl:["#bBank"],ok:"Así: entras a tu banco desde aquí, copias o capturas tus movimientos y vuelves para importarlos.",
  anim:function(){return[{cap:"Pulsa «🏦 Mi banco»…",click:"#bBank"},{cap:"…y elige «Añadir mi banco».",click:'#mBank [data-open="bankbox"]',wait:500},
   {cap:"Escribes un nombre y la dirección de la web de tu banco (aquí, un ejemplo)…",type:".bkn",text:"Mi banco"},{type:".bku",text:"mibanco.es"},
   {cap:"…y pulsas «Guardar».",click:"#bkSave",wait:700},
   {cap:"A partir de ahora, con «Mi banco» llegas a tu banco con un clic.",click:"#bBank",wait:2200},{click:"#bBank"}]}}]},
{t:"Corrige una categoría",start:function(i){tourFocusRow(i.taller,false)},stages:[
 {say:"Toca «Taller Hnos. Ruiz».",why:"La app clasifica cada gasto sola, pero este comercio no lo reconoce y lo deja en «Otros». Al tocar un movimiento se abren sus opciones.",hl:function(i){return[tourRow(i.taller)]},demo:function(i){return[{click:tourRow(i.taller)}]},done:function(i){return editing===i.taller},auto:function(i){tourFocusRow(i.taller,true)}},
 {say:"Elige «Transporte y coche».",why:"Corregirlo una vez le enseña a la app: la próxima vez que salga este comercio, o uno parecido, se clasificará sola.",ctx:function(i){return[tourRow(i.taller)]},hl:function(i){return[tourRow(i.taller)+" .edit .cs"]},demo:function(i){return[{select:tourRow(i.taller)+" .edit .cs",value:"Transporte y coche"}]},done:function(i){return catOf(ix.by[i.taller])!=="Otros"},auto:function(i){setRule(i.taller,"Transporte y coche")},ok:"Hecho: la app lo recuerda y lo aplicará a comercios parecidos.",redo:{cond:function(i){return editing!==i.taller},to:0}}]},
{t:"Busca y filtra",start:function(i){sel=i.selKey;q="";$("q").value="";fday=null;fcat=null;editing=null;ed=null;setFilter("all");render()},stages:[
 {say:"Escribe «Mercadona» en el buscador.",why:"Con muchos movimientos, buscar es lo más rápido: la lista se reduce al instante a los que coinciden (busca por comercio o por categoría).",ctx:["#fbar"],hl:["#q"],demo:function(){return[{type:"#q",text:"Mercadona"}]},fade:true,done:function(){return q.indexOf("mercadona")>-1},auto:function(){var e=$("q");e.value="Mercadona";e.dispatchEvent(new Event("input",{bubbles:true}))},ok:"Solo quedan los movimientos que coinciden, con su total justo encima."},
 {say:"Pulsa «Ingresos».",why:"Estos botones filtran por tipo: Todos, Gastos, Ingresos o Por cobrar. También puedes tocar un día del gráfico «Gasto del mes», o una categoría de «Por categoría», para ver solo esos movimientos.",ctx:["#fbar"],hl:['[data-f="in"]'],enter:function(){q="";$("q").value="";renderRows()},demo:function(){return[{click:'[data-f="in"]'}]},fade:true,done:function(){return filter==="in"},auto:function(){var b=document.querySelector('[data-f="in"]');if(b)b.click()},ok:"Se pueden combinar la búsqueda y los filtros. Pulsa «Todos» para volver a verlo todo."}]},
{t:"Comparte un gasto",start:function(i){tourFocusRow(i.cena,false)},stages:[
 {say:"Toca «Cena Sushi Kyoto».",why:"Imagina que pagaste tú esta cena de varios y te van a devolver su parte: tu gasto real es solo lo tuyo.",hl:function(i){return[tourRow(i.cena)]},demo:function(i){return[{click:tourRow(i.cena)}]},done:function(i){return editing===i.cena},auto:function(i){tourFocusRow(i.cena,true)}},
 {say:"Pulsa «Marcar como compartido».",why:"Así la app sabe que ese dinero no es solo tuyo y no te cuenta como gasto lo que te deben devolver.",ctx:function(i){return[tourRow(i.cena)]},hl:function(i){return[tourRow(i.cena)+" .edit .shr"]},demo:function(i){return[{click:tourRow(i.cena)+" .edit .shr"}]},done:function(i){return!!shared[i.cena]},auto:function(i){toggleShared(i.cena)},redo:{cond:function(i){return editing!==i.cena},to:0}},
 {say:"Elige con quién y pulsa «Guardar».",why:"Apuntas quién te debe. Mientras no te pague, el gasto sale en «Pendiente de cobrar».",ctx:function(i){return[tourRow(i.cena)]},hl:function(i){return[tourRow(i.cena)+" .shd"]},demo:function(i){return[{click:tourRow(i.cena)+" .shd .pch"},{click:tourRow(i.cena)+" .shd .psv"}]},done:function(i){var v=shared[i.cena];return!!(v&&v.p&&v.p.length)},auto:function(i){if(!sdr||sdr.k!==i.cena)sdr={k:i.cena,p:[]};sdr.p=[{n:"Ana"}];saveShare(i.cena)},ok:"Queda en «Pendiente de cobrar» y en la lista con una etiqueta amarilla.",redo:{cond:function(i){return editing!==i.cena||!shared[i.cena]},to:0}}]},
{t:"Salda el gasto con el Bizum",start:function(i){tourFocusRow(i.bizum,false)},stages:[
 {say:"Toca el Bizum de «Carlos Gil».",why:"Cuando te pagan lo que te debían, el Bizum entra como un ingreso más. Hay que decirle a la app que es la devolución de aquella cena.",ctx:["#pend"],hl:function(i){return[tourRow(i.bizum)]},demo:function(i){return[{click:tourRow(i.bizum)}]},done:function(i){return editing===i.bizum},auto:function(i){tourFocusRow(i.bizum,true)}},
 {say:"Pulsa «Es reembolso de…».",why:"Te deja elegir cuál es el gasto que te están devolviendo.",ctx:function(i){return[tourRow(i.bizum)]},hl:function(i){return[tourRow(i.bizum)+" .edit .pk"]},demo:function(i){return[{click:tourRow(i.bizum)+" .edit .pk"}]},done:function(i){return pick===i.bizum||!!links[i.bizum]},auto:function(i){pick=i.bizum;pickE=null;renderRows()},redo:{cond:function(i){return editing!==i.bizum&&!links[i.bizum]},to:0}},
 {say:"Elige «Cena Sushi Kyoto» (y, si te lo pregunta, a la persona).",why:"Al enlazarlos, el gasto pasa a contar solo lo que te costó a ti, y el Bizum deja de contar como ingreso.",ctx:[".pick"],hl:function(i){return['.pc[data-e="'+i.cena+'"]']},demo:function(i){return[{click:'.pc[data-e="'+i.cena+'"]'},{click:".pick .pp",opt:true}]},done:function(i){return!!links[i.bizum]},auto:function(i){setLink(i.bizum,i.cena)},ok:"El gasto cuenta ya solo lo que te costó, el Bizum no cuenta como ingreso y desaparece de «Pendiente de cobrar».",redo:{cond:function(i){return pick!==i.bizum&&!links[i.bizum]},to:1}}]},
{t:"Añade un gasto a mano",
 play:function(){return[{cap:"Para apuntar un gasto a mano: pulsa «＋ Añadir»…",click:"#bPlus"},{cap:"…y elige «Añadir a mano».",click:'#mPlus [data-open="addbox"]',wait:500}]},
 stages:[
 {say:"Escribe un importe y un concepto, y pulsa «Añadir».",why:"Para lo que no pasa por el banco, como pagar en efectivo. Por ejemplo, 3,50 y «Café»: con la categoría en «Automática», la app la deduce sola por el concepto.",ctx:["#addbox"],hl:["#ma","#mn","#bAdd"],enter:function(i){openBox("addbox");$("md").value=i.selKey+"-28"},demo:function(){return[{set:"#ma",value:"3.5"},{type:"#mn",text:"Café"},{click:"#bAdd"}]},done:function(){return Object.keys(months).some(function(m){return months[m].some(function(x){return x.man})})},auto:function(){$("ma").value="3.5";$("mn").value="Café";addManual()},ok:"Tu gasto ya cuenta en los totales y los gráficos, igual que los importados.",redo:{cond:function(){return!$("addbox").open},to:0}}]},
{t:"Entiende tus números",start:function(i){tourFocusRow(i.tras,false)},stages:[
 {say:"Mira cómo va tu mes de un vistazo.",why:"«Gasto del mes» junta lo gastado cada día (barras, por categoría) y lo acumulado (línea) frente al mes anterior. «Evolución mensual» compara tus meses: pulsa uno para verlo. Y en «Por categoría», las flechas ▲▼ dicen si gastas más o menos que el mes anterior en cada categoría.",info:true,hl:['[data-panel="p_mes"]','[data-panel="p_evo"]','[data-panel="p_cat"]'],ok:"Con eso ves enseguida si vas mejor o peor que otros meses, y en qué.",
  anim:function(){return[{cap:"«Gasto del mes»: barras por día y la línea de lo acumulado.",hover:'[data-panel="p_mes"]',wait:3000},{cap:"«Evolución mensual»: un vistazo a todos tus meses.",hover:'[data-panel="p_evo"]',wait:3000},{cap:"Y las flechas de «Por categoría» comparan con el mes anterior.",hover:'[data-panel="p_cat"]',wait:3000}]}},
 {say:"«Pagos fijos» los encuentra solo.",why:"Cuando un comercio te cobra algo parecido cada mes (suscripciones, seguros, cuotas…), la app lo detecta y suma lo que tienes comprometido al mes. Si alguno no es un pago fijo, lo quitas con la ✕.",info:true,hl:['[data-panel="p_fix"]'],ok:"Así sabes cuánto sale cada mes aunque no hagas nada.",
  anim:function(){return[{cap:"Aquí aparecen los cobros que se repiten cada mes…",hover:'[data-panel="p_fix"]',wait:3200},{cap:"…con el total que te cuestan al mes.",hover:'[data-panel="p_fix"] #fixl',wait:2600}]}},
 {say:"Toca «Traspaso cuenta ahorro».",why:"Mover dinero a tu otra cuenta no es un gasto de verdad, pero cuenta como si lo fuera y te falsea los totales. Con las compras enormes y puntuales pasa igual.",hl:function(i){return[tourRow(i.tras)]},demo:function(i){return[{click:tourRow(i.tras)}]},done:function(i){return editing===i.tras},auto:function(i){tourFocusRow(i.tras,true)}},
 {say:"Pulsa «No contar en estadísticas».",why:"El movimiento se queda en la lista (atenuado), pero deja de contar en totales, gráficos y medias. Si te equivocas, pulsa «Deshacer» en el aviso o «Volver a contar».",ctx:function(i){return[tourRow(i.tras)]},hl:function(i){return[tourRow(i.tras)+" .edit .exc"]},demo:function(i){return[{click:tourRow(i.tras)+" .edit .exc"}]},done:function(i){return!!excl[i.tras]},auto:function(i){toggleExcl(i.tras)},ok:"Fíjate cómo baja el total del mes: ese traspaso ya no cuenta como gasto.",redo:{cond:function(i){return editing!==i.tras&&!excl[i.tras]},to:2}},
 {say:"Pon un presupuesto a una categoría.",why:"En ⚙ Ajustes → «Categorías» escribes cuánto quieres gastar al mes en cada una. En «Por categoría» verás una barra que se llena, se pone ámbar cerca del límite y roja si te pasas.",info:true,hl:["#bGear"],ok:"Así te das cuenta a tiempo, sin tener que echar cuentas.",
  anim:function(){return[{cap:"En ⚙ Ajustes → «Categorías» puedes poner un presupuesto mensual.",click:"#bGear"},{click:'#mGear [data-open="catbox"]',wait:500},{cap:"Por ejemplo, 160 € al mes para Supermercado…",type:".crow:nth-of-type(2) .cbud",text:"160"},{cap:"…guardas los cambios…",click:".csave",wait:700},{click:"#catbox .sh-h .btn",wait:500},
   {cap:"…y en «Por categoría» aparece una barra que se llena según gastas.",hover:'[data-panel="p_cat"]',wait:3200}]}}]},
{t:"Todo es personalizable",stages:[
 {say:"Categorías y paneles son tuyos.",why:"En ⚙ Ajustes → «Categorías» cambias nombres, colores y palabras clave, y creas las tuyas. En «Personalizar paneles» eliges qué tarjetas y paneles ver, y en qué orden, e incluso creas tarjetas con tus categorías. Lo que ocultes no se borra.",info:true,hl:["#bGear"],ok:"Todo eso lo cambias cuando quieras, y nada se pierde.",
  anim:function(){var P='#prefs .prf[data-id="p_top"] .pon',PAN='[data-panel="p_top"]';return[{cap:"Mira: todo esto se personaliza desde ⚙ Ajustes.",click:"#bGear"},{cap:"«Personalizar paneles»: eliges qué ver y en qué orden…",click:'#mGear [data-open="prefbox"]',wait:500},
   {cap:"Fíjate en el panel «Dónde más gastas», que se ve en la pantalla…",fn:function(){$("prefbox").classList.add("tour-compact");var e=document.querySelector(PAN);if(e)window.scrollTo(0,Math.max(0,e.getBoundingClientRect().top+window.scrollY-380));return tw(500)}},{hover:PAN,wait:900},
   {cap:"…y le quitamos la marca.",click:P,also:[PAN],wait:2800},
   {cap:"El panel ha desaparecido de la pantalla. Si volvemos a marcarlo…",click:P,wait:900},{hover:PAN,wait:2600},
   {cap:"…vuelve a aparecer: lo que ocultas no se borra.",click:"#prefbox .sh-h .btn",wait:400},{fn:function(){$("prefbox").classList.remove("tour-compact");window.scrollTo(0,0);return tw(300)}},
   {cap:"Y en «Categorías» cambias nombres, colores y palabras clave, o creas las tuyas.",click:"#bGear"},{click:'#mGear [data-open="catbox"]',wait:500},{hover:"#catman .crow .ck",wait:2200},{click:"#catbox .sh-h .btn",wait:400}]}}]},
{t:"¡Lo has conseguido!",intro:"Ya sabes lo esencial: <b>importar</b> movimientos (por texto o por captura, entrando a tu banco desde «Mi banco»), <b>corregir</b> categorías, <b>buscar y filtrar</b>, <b>compartir</b> gastos y saldarlos con el Bizum, <b>añadir</b> a mano y <b>entender tus números</b> (evolución, pagos fijos, presupuestos y lo que no debe contar). Y todo es personalizable.<br><br>%DATOS%<br><span class=\"mut\">Puedes repetir esta guía en ⚙ Ajustes → Guía paso a paso.</span>",fin:"Salir de la demostración"}];
function tourSteps(){return TOUR.length-2}
function tourStageObj(){var st=TOUR[tourI];return st&&st.stages?st.stages[tourS]:null}
function tourTxt(t){return t.replace("%DATOS%",appServer?"Al salir, empiezas con tus datos reales, que se guardan en <b>datos.json</b> con una copia diaria. Otro día, ábrela con un doble clic en <b>Mis gastos</b>.":"Al salir, empiezas con tus datos reales, que se guardan <b>solo en este navegador</b>. Otro día, vuelve a abrir este mismo archivo y tus datos seguirán ahí. De vez en cuando, descarga una copia de seguridad desde ⚙ Ajustes.")}
function renderTour(){var st=TOUR[tourI],box=$("tour"),sg=tourStageObj(),n=tourSteps(),dots="",i,html,kick;
 for(i=1;i<=n;i++)dots+='<i class="'+(i<=tourI?"on":"")+'"></i>';
 box.className="tour"+(st.intro?" center":"");box.hidden=false;
 kick=st.intro?(st.fin?"Final":"Visita guiada"):"Paso "+tourI+" de "+n+" · "+st.t;
 html='<div class="tour-top"><span class="tour-n">'+kick+'</span>'+(tourI===0&&st.intro&&!st.fin?"":'<button class="btn tx" data-tour="stop">'+(st.skip||"Salir de la guía")+"</button>")+"</div>";
 if(tourAnimating){html+='<p class="tour-demo">▶ Mira cómo se hace</p><p class="tour-say"><span class="tour-u">'+(tourCap||"…")+'</span></p>'+(tourAnimWhy?'<p class="tour-why">'+tourAnimWhy+"</p>":"")+'<div class="tour-nav"><span class="tour-links"><button class="btn tx" data-tour="skipanim">Saltar animación</button></span><span class="tour-dots">'+dots+"</span></div>"}
 else if(st.intro){html+="<h3>"+st.t+'</h3><div class="tour-b"><p>'+tourTxt(st.intro)+"</p>"+(tourI===0&&!st.fin?'<p class="tour-ask"><b>¿Quieres hacer el tutorial inicial?</b></p>':"")+'</div><div class="tour-nav">'+(tourI===0&&!st.fin?'<button class="btn" data-tour="stop">'+(st.skip||"Ahora no")+"</button>":"<span></span>")+'<span class="tour-dots"></span>'+(st.fin?'<button class="btn pri" data-tour="fin">'+st.fin+"</button>":'<button class="btn pri" data-tour="next">'+(tourI===0?"Sí, empezar":st.next)+"</button>")+"</div>"}
 else if(tourOk){html+='<div class="tour-ok"><span class="tick">✓</span> ¡Hecho!</div>'+(tourOk!==true?'<p class="tour-why">'+tourOk+"</p>":"")}
 else{html+='<p class="tour-say">'+sg.say+"</p>"+(sg.why?'<p class="tour-why">'+sg.why+"</p>":"")+'<div class="tour-nav"><span class="tour-links">'+(sg.info?"":(sg.auto?'<button class="btn tx" data-tour="auto">Hazlo por mí</button>':"")+'<button class="btn tx" data-tour="skip">Saltar este paso</button>')+'</span><span class="tour-dots">'+dots+"</span>"+(sg.info?'<button class="btn pri" data-tour="ok">Entendido</button>':"")+"</div>"}
 box.innerHTML=html;tourMeasure();tourSpot()}
function tourMeasure(){var b=$("tour");if(b&&!b.hidden&&tourI>0)document.documentElement.style.setProperty("--tourh",b.offsetHeight+"px")}
window.addEventListener("resize",tourMeasure);
function tourRestoreSels(){tourSels=tourStSels;tourCtx=tourStCtx;tourSpot()}
function tourStage(j){tourTok++;tourS=j;tourOk="";tourBusy=false;tourSels=[];tourCtx=[];var sg=tourStageObj();if(!sg)return;if(sg.when&&!sg.when()){var st0=TOUR[tourI];if(j+1<st0.stages.length)tourStage(j+1);else tourGo(tourI+1);return}tourBefore=tourSnap();if(sg.enter)sg.enter(tourInfo);
 var h=typeof sg.hl==="function"?sg.hl(tourInfo):sg.hl,c=typeof sg.ctx==="function"?sg.ctx(tourInfo):sg.ctx;tourStSels=h||[];tourStCtx=c||[];tourSels=tourStSels;tourCtx=tourStCtx;renderTour();tourHighlight(tourSels);
 if(sg.anim){var tk=tourTok,sc=sg.anim(tourInfo);sc.unshift({cap:sg.say});
  tourAnimate(sc,sg.why).then(function(){if(!tourOn||tk!==tourTok)return;tourRestoreSels();tourBusy=true;tourOk=sg.ok||true;renderTour();
   setTimeout(function(){if(!tourOn||tk!==tourTok)return;var st=TOUR[tourI];if(tourS+1<st.stages.length)tourStage(tourS+1);else tourGo(tourI+1)},3000)})}}
async function tourAuto(){var sg=tourStageObj(),tk=tourTok;if(!sg||tourAnimating||tourBusy)return;
 if(sg.demo){var sc=sg.demo(tourInfo);sc.unshift({cap:sg.say});await tourAnimate(sc,sg.why)}
 await tw(700);
 if(!tourOn||tk!==tourTok)return;var d=false;try{d=sg.done(tourInfo)}catch(e){}if(!d&&sg.auto)sg.auto(tourInfo);tourRestoreSels();renderTour()}
function tourStopTimer(){if(tourTimer){clearInterval(tourTimer);tourTimer=null}}
function tourPoll(){if(tourAnimating)return;tourSpot();var sg=tourStageObj();if(!tourOn||tourBusy||!sg)return;
 var done=false;if(!sg.info){try{done=sg.done(tourInfo)}catch(e){}}
 if(done){tourBusy=true;tourOk=sg.ok||true;tourSels=[];tourCtx=[];renderTour();var tk=tourTok,snap=tourBefore;setTimeout(function(){if(tourOn&&tk===tourTok){tourDiff(snap);if(sg.fade){var r=$("rows");r.classList.remove("tour-fade");void r.offsetWidth;r.classList.add("tour-fade");setTimeout(function(){r.classList.remove("tour-fade")},900)}}},220);
  setTimeout(function(){if(!tourOn||tk!==tourTok)return;var st=TOUR[tourI];if(tourS+1<st.stages.length)tourStage(tourS+1);else tourGo(tourI+1)},sg.ok?3800:1500);return}
 if(sg.redo){var re=false;try{re=sg.redo.cond(tourInfo)}catch(e){}if(re)tourStage(sg.redo.to)}}
function tourBegin(){tourStage(0);tourTimer=setInterval(tourPoll,250)}
function tourGo(i){tourTok++;tourAnimTok++;tourAnimFinish();$("prefbox").classList.remove("tour-compact");tourI=Math.max(0,Math.min(TOUR.length-1,i));tourStopTimer();tourBusy=false;tourOk="";tourS=0;["impbox","addbox","catbox","prefbox","iabox","helpbox"].forEach(closeBox);closeMenus();tourSels=[];tourCtx=[];
 if(tourI>=1&&!demoMode)tourInfo=demoApi.start();
 var st=TOUR[tourI];if(st.start)st.start(tourInfo);
 if(st.stages){if(st.play){var tk=tourTok;renderTour();tourAnimate(st.play(tourInfo)).then(function(){if(tourOn&&tk===tourTok)tourBegin()})}else tourBegin()}
 else{renderTour();if(tourI===0)window.scrollTo(0,0)}}
function tourStart(i){closeMenus();tourHide0=hide;tourOn=true;if(!tourLoopRaf)tourLoopRaf=requestAnimationFrame(tourLoop);document.body.classList.add("tour-on");tourGo(i||0)}
function tourStop(done){$("prefbox").classList.remove("tour-compact");tourOn=false;tourRingLast="";tourClipLast="";tourTok++;tourAnimTok++;tourAnimFinish();tourStopTimer();document.body.classList.remove("tour-on");tourSels=[];tourCtx=[];tourSpot();["impbox","addbox","catbox","prefbox","iabox","helpbox"].forEach(closeBox);closeMenus();
 $("tour").hidden=true;$("tour").innerHTML="";if(hide!==tourHide0)setHide(tourHide0);if(demoMode&&demoApi.end)demoApi.end();try{localStorage.setItem("gastos_tour","1")}catch(e){}
 if(done&&!keys().length)openBox("impbox")}
document.addEventListener("click",function(e){var b=e.target.closest("[data-tour]");if(!b)return;var a=b.dataset.tour;
 if(a==="start")tourStart(0);else if(a==="stop")tourStop();else if(a==="fin")tourStop(true);
 else if(a==="next")tourGo(tourI+1);
 else if(a==="skip")tourGo(tourI+1);
 else if(a==="skipanim"){tourAnimTok++;tourAnimFinish();tourRestoreSels();renderTour()}
 else if(a==="ok"){var st2=TOUR[tourI];if(tourS+1<st2.stages.length)tourStage(tourS+1);else tourGo(tourI+1)}
 else if(a==="auto")tourAuto()});
/* ===== Evolucion mensual: gasto e ingresos de cada mes ===== */
function shortEur(v){return hide?"":(v>=1000?(v/1000).toFixed(1).replace(".",",")+"k":String(Math.round(v)))}
function renderEvo(){var box=$("evo");if(!box)return;var ks=keys().slice(-12),now=new Date(),nk=now.getFullYear()+"-"+("0"+(now.getMonth()+1)).slice(-2);
 if(ks.length<2){box.innerHTML='<p class="mut">Cuando tengas dos o más meses cargados verás aquí cómo evolucionan tus gastos e ingresos.</p>';$("evoTxt").textContent="";return}
 var R=ks.map(function(k){var st=stats(k);return{k:k,sp:st.total,inc:st.inc+st.ints}}),mx=Math.max.apply(null,R.map(function(r){return Math.max(r.sp,r.inc)}).concat([1]));
 var W=520,H=210,slot=W/R.length,bw=Math.min(56,slot*.62),base=H-26,ph=H-26-28,full=R.filter(function(r){return r.k!==nk}),avg=full.length?full.reduce(function(a,r){return a+r.sp},0)/full.length:0,avgI=full.length?full.reduce(function(a,r){return a+r.inc},0)/full.length:0,o="";
 R.forEach(function(r,i){var x=i*slot+(slot-bw)/2,h=Math.max(r.sp/mx*ph,1.5),yi=base-r.inc/mx*ph,top=Math.min(base-h,r.inc>0?yi:base-h),sel0=r.k===sel;
  o+='<g class="eb'+(sel0?" on":"")+(r.k===nk?" now":"")+'" data-m="'+r.k+'" tabindex="0" role="button" aria-label="'+esc(mlabel(r.k))+": gasto "+eur(r.sp)+", ingresos "+eur(r.inc)+'"><title>'+esc(mlabel(r.k))+" · gasto "+eur(r.sp)+" · ingresos "+eur(r.inc)+'</title><rect class="eh" x="'+(i*slot).toFixed(1)+'" y="0" width="'+slot.toFixed(1)+'" height="'+H+'"/><rect class="ebar" style="--i:'+i+'" x="'+x.toFixed(1)+'" y="'+(base-h).toFixed(1)+'" width="'+bw.toFixed(1)+'" height="'+h.toFixed(1)+'" rx="5"/>'
   +(r.inc>0?'<line class="einc" x1="'+(x-5).toFixed(1)+'" x2="'+(x+bw+5).toFixed(1)+'" y1="'+yi.toFixed(1)+'" y2="'+yi.toFixed(1)+'"/>':"")
   +'<text class="ax ev" x="'+(x+bw/2).toFixed(1)+'" y="'+Math.max(top-6,10).toFixed(1)+'" text-anchor="middle">'+shortEur(r.sp)+'</text><text class="ax" x="'+(x+bw/2).toFixed(1)+'" y="'+(H-8)+'" text-anchor="middle">'+MN[+r.k.slice(5)-1].slice(0,3)+"</text></g>"});
 var ya=base-avg/mx*ph;if(full.length>1)o+='<line class="eavg" x1="0" x2="'+W+'" y1="'+ya.toFixed(1)+'" y2="'+ya.toFixed(1)+'"/>';
 box.innerHTML='<svg viewBox="0 0 '+W+" "+H+'" role="group" aria-label="Gasto e ingresos de cada mes">'+o+"</svg><div class=\"legend\"><span><i class=\"sw\"></i>Gasto del mes</span><span><i class=\"sw inc\"></i>Ingresos</span>"+(full.length>1?"<span><i class=\"d\"></i>Media de gasto</span>":"")+"</div>";
 var cs=R.filter(function(r){return r.k===sel})[0],t="";if(full.length)t="Media mensual de gasto: "+eur(avg)+" (sin contar el mes en curso) · ingresos: "+eur(avgI)+".";
 if(cs&&full.length&&avg>0&&sel!==nk){var df=(cs.sp-avg)/avg*100;t+=" "+MN[+sel.slice(5)-1].charAt(0).toUpperCase()+MN[+sel.slice(5)-1].slice(1)+": "+(Math.abs(df)<1?"en la media":Math.round(Math.abs(df))+"% "+(df<0?"por debajo":"por encima"))+"."}
 $("evoTxt").textContent=hide?"":t}
function evoGo(m){if(!m||m===sel)return;sel=m;fday=null;fcat=null;editing=null;render()}
$("evo").addEventListener("click",function(e){var x=e.target.closest("[data-m]");if(x)evoGo(x.dataset.m)});
$("evo").addEventListener("keydown",function(e){var x=e.target.closest&&e.target.closest("[data-m]");if(x&&(e.key==="Enter"||e.key===" ")){e.preventDefault();evoGo(x.dataset.m)}});
/* ===== Pagos fijos: comercios que cobran algo parecido cada mes ===== */
function fixKey(it){return norm(it.n).replace(/\s*\d+$/,"").trim()}
function fixedList(){var by={},ks=keys(),no={};getPrefs().fixno.forEach(function(k){no[k]=1});
 ks.forEach(function(m){months[m].forEach(function(it){if(it.a>=0||isOut(it)||ix.lk[it.k])return;var c=catOf(it);if(INC[c]||c==="Entre cuentas"||/^Bizum/.test(c))return;var k=fixKey(it);if(!k||no[k])return;
  var g=by[k]=by[k]||{k:k,n:it.n,items:[],ms:{},cat:c};g.items.push(it);g.ms[m]=(g.ms[m]||0)+1;if(it.d>=g.items[0].d)g.n=it.n;g.cat=c})});
 var out=[];Object.keys(by).forEach(function(k){var g=by[k],nm=Object.keys(g.ms);if(nm.length<3)return;if(nm.some(function(m){return g.ms[m]>2}))return;
  var am=g.items.map(function(it){return-it.a}).sort(function(a,b){return a-b}),med=am[Math.floor(am.length/2)],ok=am.filter(function(v){return Math.abs(v-med)<=Math.max(1,med*.12)}).length;if(ok<am.length*.7)return;
  var last=g.items.slice().sort(function(a,b){return a.d<b.d?1:-1})[0],nn=g.n;if(nn===nn.toUpperCase())nn=nn.toLowerCase().replace(/(^|\s)\S/g,function(c){return c.toUpperCase()});
  out.push({k:k,n:nn,med:med,months:nm.length,last:last,up:-last.a>med*1.1,cat:g.cat})});
 return out.sort(function(a,b){return b.med-a.med})}
function renderFix(){var ul=$("fixl");if(!ul)return;var L=fixedList(),tot=0;L.forEach(function(x){tot+=x.med});
 $("fixT").textContent=L.length?"Pagos fijos · ≈ "+(hide?"•••• €":eur(tot))+" al mes":"Pagos fijos";
 ul.innerHTML=L.map(function(x){return'<li><span><i class="dot" style="background:'+col(x.cat)+'"></i>'+esc(x.n)+(x.up?' <span class="pill">Ha subido</span>':"")+'</span><span class="mut">último '+dlabel(x.last.d).replace(/^\S+\s/,"")+'</span><b>'+eur(x.med)+'</b><button class="btn tx fxn" data-q="'+esc(x.k)+'" title="No es un pago fijo" aria-label="Quitar «'+esc(x.n)+'» de los pagos fijos">✕</button></li>'}).join("");
 $("fixn").textContent=L.length?"Cobros de una cantidad parecida que se repiten cada mes. Pulsa ✕ si alguno no es un pago fijo.":"Todavía no detecto ninguno: hacen falta al menos 3 meses con un cobro parecido de un mismo comercio."}
$("fixl").addEventListener("click",function(e){var b=e.target.closest(".fxn");if(!b)return;mutPrefs(function(P){if(P.fixno.indexOf(b.dataset.q)<0)P.fixno.push(b.dataset.q)})});
/* Gráfico de disco de «Por categoría»: un trozo por categoría, con su color. Al pasar por un trozo (o por su fila) el centro enseña su detalle. */
var donutData={};
function donutRender(ents,total){var box=$("cdonut"),sum=0,off=0,segs="",i;ents.forEach(function(e){sum+=e[1]});donutData={};
 if(!(sum>0)){box.innerHTML="";return}
 ents.forEach(function(e,i){var pc=e[1]/sum*100,len=Math.max(pc-(ents.length>1?.7:0),.5);donutData[e[0]]={n:cname(e[0]),v:e[1],p:Math.round(e[1]/(total>0?total:sum)*100)};
  segs+='<circle class="seg" data-c="'+esc(e[0])+'" style="--i:'+i+'" cx="100" cy="100" r="76" fill="none" stroke="'+col(e[0])+'" pathLength="100" stroke-dasharray="'+len.toFixed(2)+' 100" stroke-dashoffset="'+(-off).toFixed(2)+'" transform="rotate(-90 100 100)" tabindex="0" role="button" aria-label="'+esc(cname(e[0]))+': '+eur(e[1])+'"><title>'+esc(cname(e[0]))+" · "+eur(e[1])+"</title></circle>";off+=pc});
 box.innerHTML='<svg viewBox="0 0 200 200" role="group" aria-label="Reparto del gasto por categoría"><circle cx="100" cy="100" r="76" fill="none" class="seg0"/>'+segs+'<text class="dc-a" x="100" y="97" text-anchor="middle"></text><text class="dc-b" x="100" y="120" text-anchor="middle"></text></svg>';
 donutData["__total__"]={n:"Gastado",v:sum,p:0};donutHover(null)}
function donutHover(c){var svg=document.querySelector("#cdonut svg");if(!svg)return;c=c||fcat;var d=c&&donutData[c]?donutData[c]:donutData["__total__"];if(!d)return;
 svg.classList.toggle("has",!!(c&&donutData[c]));var a=svg.querySelector(".dc-a"),b=svg.querySelector(".dc-b");a.textContent=eur(d.v);b.textContent=c&&donutData[c]?d.n+" · "+d.p+"%":d.n;
 svg.querySelectorAll(".seg").forEach(function(g){g.classList.toggle("on",!!c&&g.dataset.c===c)})}
/* Movimiento: al abrir la web o cambiar de mes, el contenido entra con una pequeña animación (solo en esos momentos, no en cada cambio). */
var lastMotionSel=null;
function reduceMotion(){try{return window.matchMedia("(prefers-reduced-motion: reduce)").matches}catch(e){return false}}
function stag(q,step,max){var l=document.querySelectorAll(q);for(var i=0;i<l.length;i++)l[i].style.setProperty("--i",Math.min(i,max||99)+"")}
function countUp(el){var txt=el.textContent.trim(),v=tourNum(txt);if(v===null)return;var sg=false;if(eur(v)!==txt){if(eur(v,true)!==txt)return;sg=true}
 var fin=false,t0=performance.now()+260;el.textContent=eur(0,sg);
 function f(t){var k=Math.max(0,Math.min(1,(t-t0)/950)),e=1-Math.pow(1-k,3);if(!el.isConnected||fin)return;if(k<1){el.textContent=eur(v*e,sg);requestAnimationFrame(f)}else el.textContent=txt}
 requestAnimationFrame(f);setTimeout(function(){fin=true;if(el.isConnected)el.textContent=txt},1700)}
function motion(){if(lastMotionSel===sel)return;lastMotionSel=sel;if(tourOn||demoMode||reduceMotion())return;
 var b=document.body;b.classList.remove("enter");b.classList.toggle("first",!motion.done);motion.done=true;stag("#nav .chip",0,10);stag("#cats li",60);stag("#tops li",50);stag("#rows .day",45,14);void b.offsetWidth;b.classList.add("enter");
 clearTimeout(motion.t);motion.t=setTimeout(function(){b.classList.remove("enter")},2600);
 document.querySelectorAll(".big,.kpi b").forEach(countUp)}
function render(){
 if(cdr===null&&$("catbox").open)renderCatMan();
 buildIndex();fillPlist();renderPend();applyPrefs();if($("prefbox").open)renderPrefs();iaStat();if($("iabox").open)renderIa();renderSync();renderNav();var kw=$("kpiwrap"),ks=keys();
 if(!ks.length){kw.innerHTML='<p class="empty">'+(ready?"Todavía no hay movimientos. Pulsa «＋ Añadir → Importar movimientos» y pega tu lista de la web del banco"+(appPhotos?", o sube una captura":"")+".</p><p><button class=\"btn pri\" data-open=\"impbox\">Importar movimientos</button> <button class=\"btn\" data-tour=\"start\">Ver la guía paso a paso</button>":"Cargando…")+"</p>";["ch2","evo","fixl","cdonut","cats","cmpNote","tops","rows","lg","pend","sync"].forEach(function(i){$(i).innerHTML=""});$("panels").hidden=true;if(ready&&!tourOffered){tourOffered=true;if(!tourOn)setTimeout(function(){if(!tourOn)tourStart(0)},300)}return}
 $("panels").hidden=false; if(!sel||!months[sel]||!months[sel].length)sel=ks[ks.length-1];renderNav();
 var s=stats(sel),pk=prevKey(sel),ps=months[pk]?stats(pk):null,now=new Date(),cur=sel===now.getFullYear()+"-"+("0"+(now.getMonth()+1)).slice(-2),td=cur?now.getDate():dim(sel);
 var cmp="";if(ps){var a=0,b=0;for(var i=0;i<td;i++){a+=s.daily[i];b+=ps.daily[i]||0}var dl=a-b;
  cmp='<p class="cmp '+(dl<=0?"good":"bad")+'">'+(Math.abs(dl)<0.005?"Igual que":eur(Math.abs(dl))+(dl<0?" menos que":" más que"))+" "+MN[+pk.slice(5)-1]+(cur?" a estas alturas (día "+td+")":"")+"</p>"}
 kw.innerHTML='<div class="hero"><div class="big">'+eur(-s.total)+'</div><span class="mut">gastados en '+mlabel(sel)+'</span></div>'+cmp+
 kpisHtml(s,ps,cur,td,pk);
 var n=s.daily.length,W=720,H=230,c1=[],c2=[],t=0,u=0;
 for(var i=0;i<n;i++){t+=s.daily[i];c1.push(cur&&i+1>td?null:t);if(ps){u+=ps.daily[i]||0;c2.push(i<ps.daily.length?u:null)}}
 var mx=Math.max.apply(null,c1.concat(c2).filter(function(v){return v!=null}).concat([1]));
 var en0=Object.keys(s.spend).sort(function(a,b){return s.spend[b]-s.spend[a]}),bw=W/n,bars="",dm=1,pos=[];
 s.dc.forEach(function(o){var t=0;en0.forEach(function(c){if(o[c]>0)t+=o[c]});pos.push(t);if(t>dm)dm=t});
 s.dc.forEach(function(o,i){bars+='<g class="bg" style="--i:'+i+'">';var y=H-20,x0=(i*bw+2.5).toFixed(1),w=(bw-5).toFixed(1);if(!pos[i])bars+='<rect x="'+x0+'" y="'+(H-21.5)+'" width="'+w+'" height="1.5" class="bar0"/>';
  en0.forEach(function(c){var v=o[c];if(!(v>0))return;var h=v/dm*(H-40);y-=h;bars+='<rect x="'+x0+'" y="'+y.toFixed(1)+'" width="'+w+'" height="'+h.toFixed(1)+'" fill="'+col(c)+'"><title>'+(i+1)+" · "+esc(cname(c))+" · "+eur(v)+"</title></rect>"});bars+="</g>"});
 var sbg="",hits="";for(var di=0;di<n;di++){if(fday===di+1)sbg='<rect class="selbg" x="'+(di*bw).toFixed(1)+'" y="0" width="'+bw.toFixed(1)+'" height="'+(H-18)+'" rx="4"/>';hits+='<rect class="hit" data-d="'+(di+1)+'" x="'+(di*bw).toFixed(1)+'" y="0" width="'+bw.toFixed(1)+'" height="'+(H-18)+'" tabindex="0" role="button" aria-label="Día '+(di+1)+': '+eur(s.daily[di])+'"/>'}
 var d1=line(c1,W,H,bw/2,mx),lastI=-1;c1.forEach(function(v,i){if(v!=null)lastI=i});
 var endLbl="";if(lastI>=0&&!hide){var ex=bw/2+lastI*(W-bw)/Math.max(n-1,1),ey=H-22-(c1[lastI]/mx)*(H-40);endLbl='<text class="ax lv" x="'+Math.min(ex,W-6).toFixed(1)+'" y="'+Math.max(ey-9,11).toFixed(1)+'" text-anchor="'+(ex>W-60?"end":"middle")+'">'+Math.round(c1[lastI]).toLocaleString("es-ES")+" €</text>"}
 $("ch2").innerHTML='<svg viewBox="0 0 '+W+" "+H+'" role="group" aria-label="Gasto del mes: barras por día y línea acumulada">'+sbg+bars+(ps?'<path class="l2" d="'+line(c2,W,H,bw/2,mx)+'"/>':"")+'<path class="l1h" pathLength="1" d="'+d1+'"/><path class="l1" pathLength="1" d="'+d1+'"/>'+endLbl+axis(n,W,bw/2,H)+hits+"</svg>";
 $("lg").innerHTML='<span><i></i>Acumulado de '+MN[+sel.slice(5)-1]+" · "+eur(s.total)+"</span>"+(ps?'<span><i class="d"></i>'+MN[+pk.slice(5)-1]+" · "+eur(ps.total)+"</span>":"");
 var cmpD=function(c,v){if(!ps)return"";var pv=0;if(cur){for(var qq=0;qq<td&&qq<ps.dc.length;qq++)pv+=ps.dc[qq][c]||0}else pv=ps.spend[c]||0;var d=v-pv;if(Math.abs(d)<0.5)return"";
  return' <small class="dv '+(d>0?"up":"dn")+'" title="'+esc(eur(Math.abs(d))+(d>0?" más":" menos")+" que en "+MN[+pk.slice(5)-1]+(cur?" a estas alturas":"")+(pv>0?" ("+Math.round(Math.abs(d)/pv*100)+"%)":" (ese mes no gastaste nada aquí)"))+'">'+(d>0?"▲ ":"▼ ")+eur(Math.abs(d))+"</small>"};
 $("cmpNote").textContent=ps&&!hide?"▲▼ comparan con "+MN[+pk.slice(5)-1]+(cur?" a estas alturas del mes":"")+": en rojo gastas más; en verde, menos.":"";
 var ents=Object.keys(s.spend).map(function(k){return[k,s.spend[k]]}).sort(function(a,b){return b[1]-a[1]}),cm=ents.length?ents[0][1]:1;
 $("cats").innerHTML=ents.map(function(e){return'<li data-c="'+esc(e[0])+'" tabindex="0" class="'+(fcat===e[0]?"sel":"")+'"><span><i class="dot" style="background:'+col(e[0])+'"></i>'+esc(cname(e[0]))+cmpD(e[0],e[1])+'</span><span class="cb"><i style="width:'+Math.max(e[1]/cm*100,0).toFixed(1)+'%;background:'+col(e[0])+'"></i></span><span class="cv">'+eur(e[1])+'</span><span class="cp">'+(s.total>0?Math.round(e[1]/s.total*100):0)+"%</span>"+budHtml(e[0],e[1])+"</li>"}).join("");
 donutRender(ents,s.total);
 var mm={},cn={},nm={},cc={};s.items.forEach(function(it){if(isOut(it))return;var c=catOf(it);if(INC[c]||c==="Bizum / transferencia enviada"||c==="Entre cuentas")return;var k=norm(it.n).replace(/\s*\d+$/,"");mm[k]=(mm[k]||0)-eff(it);cn[k]=(cn[k]||0)+(it.a<0?1:0);nm[k]=nm[k]||it.n;cc[k]=cc[k]||c});
 var tp=Object.keys(mm).sort(function(a,b){return mm[b]-mm[a]}).slice(0,8);
 $("tops").innerHTML=tp.map(function(k){var nn=nm[k];if(nn===nn.toUpperCase())nn=nn.toLowerCase().replace(/(^|\s)\S/g,function(c){return c.toUpperCase()});return'<li><span><i class="dot" style="background:'+col(cc[k])+'"></i>'+esc(nn)+'</span><span class="mut">'+cn[k]+"×</span><b>"+eur(-mm[k])+"</b></li>"}).join("");
 renderEvo();renderFix();renderRows(s);motion()}
function budHtml(c,v){var b=CM[c]&&CM[c].b;if(!(b>0))return"";var p=v/b*100,k=p>100?"over":p>=80?"warn":"ok";
 return'<span class="bud '+k+'" title="Presupuesto mensual de esta categoría"><span class="bb"><i style="width:'+Math.min(p,100).toFixed(1)+'%"></i></span><em>'+(p>100?"Te has pasado "+eur(v-b):Math.round(p)+"% de "+eur(b))+"</em></span>"}
function usageMap(){var u={};Object.keys(months).forEach(function(m){months[m].forEach(function(i){if(!isVoid(i)){var c=catOf(i);u[c]=(u[c]||0)+1}})});return u}
function initCdr(){cdr={list:cats.map(function(x){var y=cl(x);y.kwt=(y.kw||[]).join(", ");return y}),redir:cl(redir),delId:null,delTo:"Otros"}}
function renderCatMan(){var box=$("catman");if(!cdr)initCdr();var use=usageMap();
 var h='<p class="mut" style="margin:10px 0 8px">Cambia el nombre, el color y las <b>palabras clave</b>: si el nombre de un comercio contiene alguna, se categoriza solo (por ejemplo «repsol, gasolina»). Una categoría de <b>ingreso</b> no cuenta como gasto. Al eliminar una, eliges a cuál pasan sus movimientos. Debajo de las palabras clave aparecen las <b>aprendidas</b>: palabras que la app detecta sola porque se repiten en varios comercios de esa categoría; quita (✕) las que no te sirvan.</p>';
 cdr.list.forEach(function(x,i){
  h+='<div class="crow" data-i="'+i+'"><div class="cl1"><input type="color" class="cc" value="'+esc(x.c)+'" aria-label="Color"><input type="text" class="cn" value="'+esc(x.n)+'" placeholder="Nombre" aria-label="Nombre de la categoría"></div><input type="text" class="ck" value="'+esc(x.kwt||"")+'" placeholder="Palabras clave separadas por comas" aria-label="Palabras clave">'+learnedHtml(x.id)+'<div class="cl3">'+(x.inc||x.id==="Entre cuentas"?"":'<label class="mut cbl">Presupuesto <input type="number" class="cbud" min="0" step="1" value="'+(x.b>0?esc(x.b):"")+'" placeholder="sin límite" aria-label="Presupuesto mensual de la categoría"> €/mes</label>')+'<select class="ct" aria-label="Tipo"'+(x.sys?" disabled":"")+'>'+(x.id==="Entre cuentas"?"<option>Ingreso o gasto</option>":'<option value="out"'+(x.inc?"":" selected")+'>Gasto</option><option value="in"'+(x.inc?" selected":"")+">Ingreso</option>")+'</select><span class="mut">'+(use[x.id]||0)+' mov.'+(x.id==="Entre cuentas"?" · entra = ingreso, sale = gasto":(x.sys?" · sistema":""))+"</span>"+(x.sys?"":'<button class="btn cdel">Eliminar</button>')+"</div>";
  if(cdr.delId===x.id)h+='<div class="cdp"><div class="mut">¿A qué categoría pasan sus movimientos?</div><div class="prow"><select class="cdt" aria-label="Categoría destino">'+cdr.list.filter(function(y){return y.id!==x.id}).map(function(y){return'<option value="'+esc(y.id)+'"'+(y.id===cdr.delTo?" selected":"")+">"+esc(y.n||"(sin nombre)")+"</option>"}).join("")+'</select><button class="btn pri cdc">Confirmar</button><button class="btn cdx">Cancelar</button></div></div>';
  h+="</div>"});
 var miss=BASE.filter(function(b){return!cdr.list.some(function(x){return x.id===b.id})});
 h+='<div class="prow" style="margin-top:10px"><button class="btn cadd">+ Nueva categoría</button>'+(miss.length?'<button class="btn crs">Recuperar originales borradas ('+miss.length+")</button>":"")+'</div><div class="prow" style="margin-top:6px"><button class="btn pri csave">Guardar cambios</button><button class="btn cdis">Descartar cambios</button></div>';
 var nb=Object.keys((learnDoc&&learnDoc.block)||{}).length;if(nb)h+='<p class="mut" style="margin-top:10px">Hay '+nb+(nb===1?" palabra aprendida bloqueada":" palabras aprendidas bloqueadas")+'. <button class="btn" id="lkres">Restaurarlas</button></p>';
 box.innerHTML=h}
async function saveCats(){if(!cdr||!coll)return;var seen={},list=[];
 for(var i=0;i<cdr.list.length;i++){var x=cdr.list[i],n=String(x.n||"").trim();if(!n){toast("Pon nombre a todas las categorías");return}var q=norm(n);if(seen[q]){toast("Hay dos categorías con el mismo nombre: «"+n+"»");return}seen[q]=1;
  list.push({id:x.id,n:n,c:/^#[0-9a-fA-F]{6}$/.test(x.c)?x.c:"#9AA5A8",inc:x.sys?(CM[x.id]?CM[x.id].inc:x.inc):(x.inc?1:0),sys:x.sys?1:0,custom:x.custom?1:0,kw:String(x.kwt||"").split(/[,;\n]/).map(function(s){return s.trim()}).filter(Boolean)});var bv=parseFloat(String(x.b).replace(",","."));if(bv>0&&!list[list.length-1].inc)list[list.length-1].b=Math.round(bv*100)/100}
 var ids={};list.forEach(function(x){ids[x.id]=1});var rd={};Object.keys(cdr.redir).forEach(function(k){var v=cdr.redir[k];if(!ids[k]&&ids[v])rd[k]=v});
 try{await coll.doc("cats").set({list:list,redir:rd});cdr=null;toast("Categorías guardadas")}catch(e){toast("No se han podido guardar las categorías")}}
var pendGs=[];
function fallbackCopy(t,ok){var a=document.createElement("textarea");a.value=t;a.style.position="fixed";a.style.opacity="0";document.body.appendChild(a);a.select();try{document.execCommand("copy");ok()}catch(e){toast("No se ha podido copiar")}a.remove()}
function copyPend(i){var g=pendGs[i];if(!g)return;var nm=g.n==="Alguien"?"":g.n,done=function(){toast("Mensaje copiado: pégalo en WhatsApp o donde quieras")},
 l=g.l.slice().sort(function(a,b){return a.d<b.d?-1:1}).map(function(it){return"• "+dlabel(it.d)+" · "+it.n+" ("+eur(-it.a)+")"}).join("\n"),
 txt="Hola"+(nm?" "+nm:"")+", te recuerdo lo que tienes pendiente de pagarme:\n"+l+"\n¡Gracias!";
 try{navigator.clipboard.writeText(txt).then(done,function(){fallbackCopy(txt,done)})}catch(e){fallbackCopy(txt,done)}}
function renderPend(){var by={},n=0;
 Object.keys(shared).forEach(function(k){var it=ix.by[k];if(!it||it.a>=0)return;var st=settle(k);if(!st)return;
  if(st.anon){if(st.pending){var g=by["__"]=by["__"]||{n:"Alguien",l:[]};g.l.push(it);n++}return}
  st.people.forEach(function(x){if(!x.paid){var q=norm(x.n),g=by[q]=by[q]||{n:x.n,l:[]};g.l.push(it);n++}})});
 var gs=Object.keys(by).map(function(q){return by[q]}).sort(function(a,b){return b.l.length-a.l.length||(a.n<b.n?-1:1)});pendGs=gs;
 $("pend").innerHTML=gs.length?'<div class="card"><h2>Pendiente de cobrar · '+n+(n===1?" pago":" pagos")+'</h2><ul class="top">'+gs.map(function(g,gi){g.l.sort(function(a,b){return a.d<b.d?1:-1});return'<li class="pr"><span>'+esc(g.n)+'</span><b>'+g.l.length+(g.l.length===1?" gasto":" gastos")+'</b><button class="btn tx cpm" data-i="'+gi+'" title="Copia un mensaje para recordárselo (por ejemplo, por WhatsApp)">Copiar mensaje</button></li>'+g.l.map(function(it,i){return'<li class="sub go'+(i===g.l.length-1?" last":"")+'" data-k="'+esc(it.k)+'" tabindex="0" role="button"><span class="mut">'+dlabel(it.d)+" · "+esc(it.n)+'</span><b class="mut">gasto de '+eur(-it.a)+"</b></li>"}).join("")}).join("")+"</ul></div>":""}
function isPend(it){if(!(it.a<0)||isVoid(it)||INC[catOf(it)])return false;var st=settle(it.k);return!!(st&&st.pending)}
function monthHasPend(m){return(months[m]||[]).some(isPend)}
function setFilter(f){filter=f;document.querySelectorAll("[data-f]").forEach(function(x){x.setAttribute("aria-pressed",x.dataset.f===f)})}
function jumpTo(k){var it=ix.by[k];if(!it)return;sel=it.d.slice(0,7);q="";$("q").value="";fday=null;fcat=null;editing=null;pick=null;pickE=null;setFilter("pend");render();scrollMov()}
function pickList(r){var rd=new Date(r.d).getTime(),l=[];Object.keys(ix.by).forEach(function(k){var e=ix.by[k];if(e.a>=0||isVoid(e)||INC[catOf(e)]||catOf(e)==="Entre cuentas")return;var dd=(rd-new Date(e.d).getTime())/864e5;if(dd<-30||dd>120)return;l.push([Math.abs(dd),e])});
 l.sort(function(a,b){var pa=isPend(a[1])?0:1,pb=isPend(b[1])?0:1;return pa-pb||a[0]-b[0]});return l.slice(0,200).map(function(x){return x[1]})}
function sharedEditor(it,sh){if(!sdr||sdr.k!==it.k)sdr={k:it.k,p:sh.p.map(function(x){return{n:x.n}})};
 var have={},kn=knownNames();sdr.p.forEach(function(x){have[norm(x.n)]=1});
 var sug=Object.keys(kn).filter(function(q){return!have[q]}).sort().slice(0,8);
 return'<div class="shd"><div class="mut">¿Con quién compartes este gasto?'+(sh.legacy?" Antes solo tenías apuntada tu parte; ahora basta con indicar con quién.":"")+"</div>"+
  sdr.p.map(function(x,i){return'<div class="prow"><input type="text" class="pn" data-i="'+i+'" list="plist" placeholder="Nombre" value="'+esc(x.n)+'" aria-label="Nombre"><button class="btn prm" data-i="'+i+'" aria-label="Quitar persona">✕</button></div>'}).join("")+
  (sug.length?'<div class="plist">'+sug.map(function(q){return'<button class="btn pch" data-n="'+esc(kn[q])+'">+ '+esc(kn[q])+"</button>"}).join("")+"</div>":"")+
  '<div class="prow"><button class="btn pad">+ Otra persona</button><button class="btn pri psv">Guardar</button></div></div>'}
function editHtml(it){var c=catOf(it),v=isVoid(it),h='<div class="edit"><select class="cs" aria-label="Categoría">'+CATS.map(function(x){return'<option value="'+esc(x)+'"'+(x===c?" selected":"")+">"+esc(cname(x))+"</option>"}).join("")+"</select>";
 if(it.a<0&&!v&&!INC[c]){var sh=shr(it.k);h+='<button class="btn shr">'+(sh?"Quitar «compartido»":"Marcar como compartido")+"</button>";if(sh)h+=sharedEditor(it,sh)}
 if(it.a>0&&!v&&(c==="Bizum / transferencia recibida"||(!INC[c]&&c!=="Entre cuentas"))){var lv=links[it.k],to=ix.lk[it.k]&&ix.by[lkE(lv)];
  if(to){h+='<span class="mut">Reembolso de «'+esc(to.n)+"» ("+dlabel(to.d)+")</span>";var s2=shr(lkE(lv));
   if(s2&&s2.p.length){var cp0=lkP(lv);h+='<label class="mut">De <select class="lp" aria-label="De quién"><option value="">Sin asignar</option>'+s2.p.map(function(x){return"<option"+(norm(x.n)===norm(cp0)?" selected":"")+">"+esc(x.n)+"</option>"}).join("")+"</select></label>"}
   h+='<button class="btn unl">Quitar enlace</button>'}
  else if(pick===it.k&&pickE&&shr(pickE)&&ix.by[pickE]){var s3=shr(pickE),st=settle(pickE),e0=ix.by[pickE],nn=norm(it.n);
   h+='<div class="pick"><div class="mut">¿De quién es este ingreso? Se marcará como pagado por esa persona en «'+esc(e0.n)+'».</div><div class="plist">'+s3.p.map(function(x){var pe=st&&st.people.filter(function(y){return norm(y.n)===norm(x.n)})[0],sg=nn.indexOf(norm(x.n))>-1;return'<button class="btn pp'+(sg?" pri":"")+'" data-n="'+esc(x.n)+'">'+esc(x.n)+(pe&&!pe.paid?" · pendiente":" · ya pagó")+"</button>"}).join("")+'<button class="btn pp" data-n="">Otra persona / sin asignar</button></div><button class="btn pb">Atrás</button></div>'}
  else if(pick===it.k){var cs=pickList(it);h+='<div class="pick"><input type="search" class="pq" placeholder="Buscar gasto: comercio, importe o fecha" aria-label="Buscar gasto"><div class="pl">'+(cs.length?cs.map(function(e){return'<button class="pc" data-e="'+esc(e.k)+'" data-s="'+esc(norm(e.n+" "+eur(e.a)+" "+dlabel(e.d)))+'"><i class="dot" style="background:'+col(catOf(e))+'"></i><span>'+dlabel(e.d)+" · "+esc(e.n)+(shr(e.k)?(isPend(e)?" 👥 por cobrar":" 👥"):"")+"</span><b>"+eur(e.a)+"</b></button>"}).join(""):'<p class="mut" style="padding:8px 10px;margin:0">No hay gastos cargados cerca de esta fecha. Importa antes el mes del gasto.</p>')+'</div><button class="btn pk">Cancelar</button></div>'}
  else h+='<button class="btn pk">Es reembolso de…</button>'}
 if(ed===it.k&&!hide){var sg2=it.a<0?"out":"in";h+='<div class="ef"><select class="ef-t" aria-label="Tipo"><option value="out"'+(sg2==="out"?" selected":"")+'>Gasto</option><option value="in"'+(sg2==="in"?" selected":"")+'>Ingreso</option></select><input type="date" class="ef-d" value="'+esc(it.d)+'" aria-label="Fecha"><input type="number" step="0.01" min="0" class="ef-a" value="'+Math.abs(it.a).toFixed(2)+'" aria-label="Importe"><input type="text" class="ef-n" value="'+esc(it.n)+'" aria-label="Concepto"><button class="btn pri efs">Guardar</button><button class="btn efc">Cancelar</button></div>'}
 else if(!hide)h+='<button class="btn edt">Editar</button>';
 if(!v)h+='<button class="btn exc" title="Si es un gasto o ingreso puntual (un traspaso, una compra enorme…) no entrará en totales, gráficos ni medias">'+(isEx(it)?"Volver a contar":"No contar en estadísticas")+"</button>";
 h+='<button class="btn del">'+(cdel===it.k?"¿Seguro? Eliminar":"Eliminar")+"</button>";
 return h+"</div>"}
function rowHtml(it,dt,wd){var c=catOf(it),v=isVoid(it),xc=!v&&isEx(it),ver=/verificaci/i.test(it.s||""),lk=ix.lk[it.k],re=ix.re[it.k]||0,exp=it.a<0&&!v&&!INC[c],hasRe=exp&&re>0.005,ex="",pill="",isp=false,
 a=ver?"—":(/rechazad/i.test(it.s||"")?"rechazado":(hasRe?eur(it.a+re,true)+'<small class="orig">pagado '+eur(it.a)+"</small>":eur(it.a,true)));
 if(lk){var lv0=links[it.k],pn=lkP(lv0);ex=" · reembolso de «"+esc(ix.by[lkE(lv0)].n)+"»"+(pn?" ("+esc(pn)+")":"")+", ya descontado"}
 else if(exp){if(hasRe)ex=" · te han devuelto "+eur(re);var st=settle(it.k);if(st){if(st.anon){if(st.pending){pill='<span class="pill">Por cobrar</span>';isp=true}else pill='<span class="pill ok">Cobrado</span>'}else{var pend=st.people.filter(function(x){return!x.paid});if(pend.length){pill='<span class="pill">Por cobrar · '+pend.map(function(x){return esc(x.n)}).join(", ")+"</span>";isp=true}else pill='<span class="pill ok">Cobrado</span>'}}}
 return'<div class="row '+(it.a>0?"in":"out")+(v?" void":"")+(xc?" excl":"")+(lk?" lked":"")+(isp?" pendc":"")+'"'+(dt?"":' data-k="'+esc(it.k)+'"')+'><span class="n">'+esc(it.n)+'<small><i class="dot" style="background:'+col(c)+'"></i>'+(wd?dlabel(it.d)+" · ":"")+esc(cname(c))+guessTxt(it)+(it.s?" · "+esc(it.s):"")+ex+'</small>'+pill+(xc?'<span class="pill nx">No cuenta</span>':'')+'</span><span class="a">'+a+"</span>"+(!dt&&editing===it.k?editHtml(it):"")+"</div>"}
function renderRows(s){buildIndex();s=s||stats(sel);var by={},cnt=0,sum=0,dd=fday?sel+"-"+("0"+fday).slice(-2):null;
 s.items.forEach(function(it){if(filter==="out"&&it.a>=0)return;if(filter==="in"&&it.a<=0)return;if(filter==="pend"&&!isPend(it))return;var c=catOf(it);if(dd&&it.d!==dd)return;if(fcat&&(isOut(it)||ix.lk[it.k]||c!==fcat))return;if(q&&(norm(it.n)+" "+norm(cname(c))).indexOf(q)<0)return;(by[it.d]=by[it.d]||[]).push(it);cnt++;if(!isOut(it)&&!ix.lk[it.k])sum+=eff(it)});
 var np=0;s.items.forEach(function(it){if(isPend(it))np++});$("fpend").textContent="Por cobrar"+(np?" · "+np:"");
 var act=fday||fcat||q||filter!=="all";
 $("fbar").innerHTML=act?(fday?'<button class="chip fx" aria-pressed="true" data-x="day">'+dlabel(dd)+" ✕</button>":"")+(fcat?'<button class="chip fx" aria-pressed="true" data-x="cat"><i class="dot" style="background:'+col(fcat)+'"></i>'+esc(cname(fcat))+" ✕</button>":"")+(fday||fcat?'<button class="chip fx" data-x="all">Quitar filtros</button>':"")+'<span class="mut">'+cnt+" movimientos · "+eur(sum,true)+"</span>":"";
 var ds=Object.keys(by).sort().reverse(),h="";
 ds.forEach(function(d){var tot=0;by[d].forEach(function(it){if(!isOut(it)&&!ix.lk[it.k])tot+=eff(it)});h+='<section class="day"><h3><span>'+dlabel(d)+'</span><span class="mut">'+eur(tot,true)+"</span></h3>";
  by[d].forEach(function(it){h+=rowHtml(it,false,false)});h+="</section>"});
 $("rows").innerHTML=h||'<p class="empty">'+(filter==="pend"?"No tienes nada pendiente de cobrar en este mes.":"Ningún movimiento coincide.")+"</p>";tourReHl()}
function fillCat(){var o=mtype==="out"?CATS.filter(function(c){return!INC[c]}):CATS.filter(function(c){return INC[c]||c==="Entre cuentas"});
 $("mc").innerHTML=(mtype==="out"?'<option value="Automática">Automática</option>':"")+o.map(function(c){return'<option value="'+esc(c)+'">'+esc(cname(c))+"</option>"}).join("")}
function today(){var n=new Date();return n.getFullYear()+"-"+("0"+(n.getMonth()+1)).slice(-2)+"-"+("0"+n.getDate()).slice(-2)}
async function addManual(){if(!coll)return;var amt=parseFloat($("ma").value),n=($("mn").value||"").trim(),d=$("md").value;
 if(!(amt>0)||!n||!/^\d{4}-\d{2}-\d{2}$/.test(d)){toast("Rellena fecha, concepto e importe");return}
 var it={k:"man|"+Date.now()+"|"+Math.random().toString(36).slice(2,7),d:d,n:n,a:Math.round((mtype==="out"?-amt:amt)*100)/100,s:"Manual",man:1},c=$("mc").value;if(c!=="Automática")it.c=c;
 var k=d.slice(0,7),cur=(months[k]||[]).map(function(i){return Object.assign({},i)});cur.push(it);cur.sort(function(a,b){return a.d<b.d?1:a.d>b.d?-1:0});
 try{await putMonth(k,cur);toast("Movimiento añadido");sel=k;fday=null;fcat=null;filter="all";q="";$("ma").value="";$("mn").value="";closeBox("addbox");if(!it.c)setTimeout(iaAuto,400)}catch(e){toast("No se ha podido guardar")}}
/* Deshacer: antes de una accion se guarda como estaba lo que va a cambiar; el aviso lleva un boton para volver atras. */
function undoSnap(ids){var o={};ids.forEach(function(id){var m=/^m-(.+)$/.exec(id);if(m)o[id]={items:(months[m[1]]||[]).map(cp)};
 else{var src={rules:rules,links:links,shared:shared,deleted:deleted,excl:excl}[id];if(src)o[id]={map:Object.assign({},src)}}});return o}
function toastUndo(msg,snap){if(demoMode||!coll){toast(msg);return}
 toast(msg,{label:"Deshacer",fn:async function(){try{for(var id in snap)await coll.doc(id).set(snap[id]);toast("Deshecho")}catch(e){toast("No se ha podido deshacer")}}})}
function cp(i){return Object.assign({},i)}
function srt(a){a.sort(function(x,y){return x.d<y.d?1:x.d>y.d?-1:0});return a}
async function delItem(k){var it=ix.by[k];if(!it)return;var m=it.d.slice(0,7),cur=(months[m]||[]).filter(function(i){return i.k!==k}).map(cp),us=undoSnap(["m-"+m,"deleted"]);
 try{if(!it.man){var dm=Object.assign({},deleted);dm[k]=1;await coll.doc("deleted").set({map:dm})}await putMonth(m,cur);cdel=null;editing=null;ed=null;toastUndo(it.man?"Movimiento eliminado":"Eliminado. Si lo vuelves a importar no reaparecerá",us)}catch(e){toast("No se ha podido eliminar")}}
async function saveEdit(k,box){var it=ix.by[k];if(!it)return;var g=function(c){return box.querySelector(c).value},ty=g(".ef-t"),d=g(".ef-d"),amt=parseFloat(g(".ef-a")),n=(g(".ef-n")||"").trim();
 if(!(amt>=0)||!n||!/^\d{4}-\d{2}-\d{2}$/.test(d)){toast("Revisa fecha, importe y concepto");return}
 var upd=Object.assign({},it,{d:d,n:n,a:Math.round((ty==="out"?-amt:amt)*100)/100}),om=it.d.slice(0,7),nm=d.slice(0,7),us=undoSnap(["m-"+om,"m-"+nm]);
 try{if(om===nm)await putMonth(om,srt((months[om]||[]).map(function(i){return i.k===k?upd:cp(i)})));
  else{await putMonth(om,(months[om]||[]).filter(function(i){return i.k!==k}).map(cp));await putMonth(nm,srt((months[nm]||[]).map(cp).concat([upd])))}
  ed=null;toastUndo("Cambios guardados",us)}catch(e){toast("No se han podido guardar los cambios")}}
async function putMonth(k,items){await coll.doc("m-"+k).set({items:items})}
function warns(its){var h="",sk=its.skipped||0,pos=its.filter(function(i){return i.a>0}).length;
 if(sk)h+='<div class="warn">⚠ '+sk+(sk===1?" movimiento tenía fecha pero no he reconocido su importe y no se importará.":" movimientos tenían fecha pero no he reconocido su importe y no se importarán.")+" Los importes deben llevar «€» (por ejemplo 12,50 €) y aparecer justo después de la fecha.</div>";
 if(its.length>=5&&pos===0)h+='<div class="warn">⚠ No veo ningún importe con «+», así que todos se importarían como gastos. Si tu banco marca los ingresos de otra forma, avísame y lo adapto.</div>';return h}
async function review(){var txt=$("paste").value,yo=parseInt($("yr").value,10)||0,its=parsePaste(txt,new Date(),yo||null),wn=warns(its);
 if(!its.length){$("prev").innerHTML='<span class="mut">No he encontrado movimientos. Comprueba que has pegado la lista completa, con fechas tipo 12/9 e importes con coma y «€».</span>'+wn;pv=null;pvDel=null;return}
 var ex={};Object.keys(months).forEach(function(k){months[k].forEach(function(i){ex[i.k]=1})});
 var nw=its.filter(function(i){return!ex[i.k]&&!deleted[i.k]}),dl=its.filter(function(i){return!ex[i.k]&&deleted[i.k]}),sk=its.length-nw.length-dl.length,bm={};nw.forEach(function(i){var k=i.d.slice(0,7);bm[k]=(bm[k]||0)+1});pv=nw;pvDel=dl;
 var ms=Object.keys(bm).sort().map(function(k){return bm[k]+" en "+mlabel(k)}).join(", "),row=function(i){return"<div><span>"+dlabel(i.d)+" · "+esc(i.n)+"</span><span>"+(isVoid(i)?"—":eur(i.a,true))+"</span></div>"};
 $("prev").innerHTML="<div><b>"+its.length+"</b> movimientos leídos: <b>"+nw.length+"</b> nuevos"+(sk?", "+sk+" que ya estaban":"")+(dl.length?" y "+dl.length+" que habías eliminado":"")+(ms?" ("+ms+")":"")+".</div>"+
 (nw.length?'<div class="list">'+nw.map(row).join("")+"</div>":"")+
 (dl.length?'<div class="dlq"><label><input type="checkbox" id="incDel"> Volver a importar también '+(dl.length===1?"el que habías eliminado":"los "+dl.length+" que habías eliminado")+'</label><div class="list">'+dl.map(row).join("")+"</div></div>":"")+
 (nw.length||dl.length?'<p><button class="btn pri" id="bSave"'+(nw.length?"":" disabled")+">Guardar "+nw.length+" nuevos</button></p>":"")+wn}
function updSave(){var b=$("bSave"),c=$("incDel");if(!b)return;var n=(pv?pv.length:0)+(c&&c.checked&&pvDel?pvDel.length:0);b.textContent="Guardar "+n+" nuevos";b.disabled=!n}
async function save(){var cd=$("incDel"),inc=cd&&cd.checked&&pvDel?pvDel:[],list=(pv||[]).concat(inc);if(!list.length||!coll)return;var by={};list.forEach(function(i){var k=i.d.slice(0,7);(by[k]=by[k]||[]).push(i)});var b=$("bSave");if(b)b.disabled=true;
 var us=undoSnap(Object.keys(by).map(function(x){return"m-"+x}).concat(["deleted"]));
 try{var ks=Object.keys(by).sort(),last=null;for(var x=0;x<ks.length;x++){var k=ks[x],cur=(months[k]||[]).map(function(i){return Object.assign({},i)}),all=cur.concat(by[k]);
   all.sort(function(a,b){return a.d<b.d?1:a.d>b.d?-1:0});await putMonth(k,all);last=k}
  if(inc.length){var dm=Object.assign({},deleted);inc.forEach(function(i){delete dm[i.k]});await coll.doc("deleted").set({map:dm})}
  try{await coll.doc("meta").set({last:Date.now()})}catch(e){}toastUndo(list.length+" movimientos guardados",us);$("paste").value="";$("prev").innerHTML="";pv=null;pvDel=null;if(last){sel=last;filter="all";q="";fday=null;fcat=null}closeBox("impbox");setTimeout(iaAuto,400)}
 catch(e){toast("No se ha podido guardar: "+(e&&e.code||e));if(b)b.disabled=false}}
async function setRule(k,c){var it=null;Object.keys(months).forEach(function(m){months[m].forEach(function(i){if(i.k===k)it=i})});if(!it)return;
 var m=Object.assign({},rules),us=undoSnap(["rules"]);m[norm(it.n)]=c;try{await coll.doc("rules").set({map:m});toastUndo("«"+it.n+"» → "+cname(c),us)}catch(e){toast("No se ha podido guardar")}}
async function saveMap(id,m,msg){var us=undoSnap([id]);try{await coll.doc(id).set({map:m});if(msg)toastUndo(msg,us)}catch(e){toast("No se ha podido guardar")}}
function setLink(r,v){var m=Object.assign({},links);if(v)m[r]=v;else delete m[r];saveMap("links",m,v?(typeof v==="object"&&v.p?"Enlazado con "+v.p:"Enlazado como reembolso"):"Enlace quitado")}
function toggleExcl(k){var m=Object.assign({},excl),on=m[k]==null;if(on)m[k]=1;else delete m[k];saveMap("excl",m,on?"Ya no cuenta en las estadísticas":"Vuelve a contar en las estadísticas")}
function toggleShared(k){var m=Object.assign({},shared);if(m[k]!=null){delete m[k];sdr=null}else{m[k]={p:[]};sdr={k:k,p:[]}}saveMap("shared",m)}
function saveShare(k){var it=ix.by[k];if(!it||!sdr||sdr.k!==k)return;var p=sdr.p.map(function(x){return{n:String(x.n||"").trim()}});
 if(p.some(function(x){return!x.n})){toast("Pon el nombre de cada persona o quita la fila vacía");return}
 var ns=p.map(function(x){return norm(x.n)});if(ns.some(function(n,i){return ns.indexOf(n)!==i})){toast("Hay dos personas con el mismo nombre");return}
 var m=Object.assign({},shared);m[k]={p:p};sdr=null;saveMap("shared",m,"Guardado")}
function download(n,x,ty){var b=new Blob([x],{type:ty}),u=URL.createObjectURL(b),a=document.createElement("a");a.href=u;a.download=n;document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(u);a.remove()},600)}
function exportCsv(){buildIndex();var r=[["fecha","comercio","importe","neto","categoria","estado"]];keys().forEach(function(k){months[k].forEach(function(i){r.push([i.d,i.n,i.a.toFixed(2),eff(i).toFixed(2),cname(catOf(i)),(ix.lk[i.k]?"reembolso":(i.s||""))])})});
 var csv="\ufeff"+r.map(function(x){return x.map(function(c){return'"'+String(c).replace(/"/g,'""')+'"'}).join(",")}).join("\n");
 download("gastos.csv",csv,"text/csv;charset=utf-8");toast("CSV descargado")}
$("nav").addEventListener("click",function(e){var b=e.target.closest("[data-m]");if(b){sel=b.dataset.m;editing=null;fday=null;fcat=null;ed=null;pick=null;render()}});
document.querySelectorAll("[data-f]").forEach(function(b){b.addEventListener("click",function(){filter=b.dataset.f;document.querySelectorAll("[data-f]").forEach(function(x){x.setAttribute("aria-pressed",x===b)});renderRows()})});
$("q").addEventListener("input",function(e){q=norm(e.target.value);renderRows()});
$("rows").addEventListener("click",function(e){var b=e.target.closest("button");if(b&&b.closest(".edit")){var k=b.closest(".row").dataset.k;if(b.classList.contains("shr"))toggleShared(k);else if(b.classList.contains("unl"))setLink(k,null);
  else if(b.classList.contains("pk")){pick=pick===k?null:k;pickE=null;renderRows()}
  else if(b.classList.contains("pc")){var ee=b.dataset.e,s4=shr(ee);if(s4&&s4.p.length){pickE=ee;renderRows()}else{pick=null;pickE=null;setLink(k,ee)}}
  else if(b.classList.contains("pp")){var nm0=b.dataset.n,ee2=pickE;pick=null;pickE=null;setLink(k,nm0?{e:ee2,p:nm0}:ee2)}
  else if(b.classList.contains("pb")){pickE=null;renderRows()}
  else if(b.classList.contains("pad")){if(sdr){sdr.p.push({n:"",a:0});renderRows()}}
  else if(b.classList.contains("prm")){if(sdr){sdr.p.splice(+b.dataset.i,1);renderRows()}}
  else if(b.classList.contains("pch")){if(sdr){sdr.p.push({n:b.dataset.n});renderRows()}}
  else if(b.classList.contains("psv"))saveShare(k);else if(b.classList.contains("exc"))toggleExcl(k);else if(b.classList.contains("del")){if(cdel===k)delItem(k);else{cdel=k;renderRows()}}else if(b.classList.contains("edt")){ed=k;renderRows()}else if(b.classList.contains("efc")){ed=null;renderRows()}else if(b.classList.contains("efs"))saveEdit(k,b.closest(".edit"));return}
 if(e.target.closest(".edit"))return;var r=e.target.closest(".row");if(r){editing=editing===r.dataset.k?null:r.dataset.k;pick=null;pickE=null;cdel=null;ed=null;renderRows()}});
$("rows").addEventListener("change",function(e){var t=e.target,r=t.closest(".row");if(!r)return;if(t.classList.contains("cs"))setRule(r.dataset.k,t.value);else if(t.classList.contains("lk")){if(t.value)setLink(r.dataset.k,t.value)}else if(t.classList.contains("lp")){var lv1=links[r.dataset.k];setLink(r.dataset.k,t.value?{e:lkE(lv1),p:t.value}:lkE(lv1))}});
$("rows").addEventListener("input",function(e){var t=e.target;if(t.classList&&t.classList.contains("pn")&&sdr){var ii=+t.dataset.i;if(sdr.p[ii])sdr.p[ii].n=t.value;return}
 if(t.classList&&t.classList.contains("pq")){var s=norm(t.value),bs=t.closest(".pick").querySelectorAll(".pc");for(var i=0;i<bs.length;i++)bs[i].style.display=(!s||bs[i].dataset.s.indexOf(s)>-1)?"":"none"}});
function scrollMov(){try{var r=$("mov").getBoundingClientRect();if(r.top>window.innerHeight*0.55||r.top<0)$("mov").scrollIntoView({behavior:(window.matchMedia&&matchMedia("(prefers-reduced-motion: reduce)").matches)?"auto":"smooth",block:"start"})}catch(e){}}
function toggleF(t,v){if(t==="day")fday=fday===v?null:v;else fcat=fcat===v?null:v;render();scrollMov()}
$("ch2").addEventListener("click",function(e){var x=e.target.closest("[data-d]");if(x)toggleF("day",+x.dataset.d)});
$("ch2").addEventListener("keydown",function(e){var x=e.target.closest&&e.target.closest("[data-d]");if(x&&(e.key==="Enter"||e.key===" ")){e.preventDefault();toggleF("day",+x.dataset.d)}});
$("cats").addEventListener("click",function(e){var x=e.target.closest("li[data-c]");if(x)toggleF("cat",x.dataset.c)});
$("cdonut").addEventListener("click",function(e){var x=e.target.closest(".seg");if(x)toggleF("cat",x.dataset.c)});
$("cdonut").addEventListener("keydown",function(e){var x=e.target.closest&&e.target.closest(".seg");if(x&&(e.key==="Enter"||e.key===" ")){e.preventDefault();toggleF("cat",x.dataset.c)}});
(function(){var w=document.querySelector(".catwrap");function on(e){var x=e.target.closest&&e.target.closest("[data-c]");if(x)donutHover(x.dataset.c)}function off(){donutHover(null)}
 w.addEventListener("mouseover",on);w.addEventListener("focusin",on);w.addEventListener("mouseleave",off);w.addEventListener("focusout",off)})();
$("cats").addEventListener("keydown",function(e){var x=e.target.closest&&e.target.closest("li[data-c]");if(x&&(e.key==="Enter"||e.key===" ")){e.preventDefault();toggleF("cat",x.dataset.c)}});
$("fbar").addEventListener("click",function(e){var x=e.target.closest(".fx");if(!x)return;if(x.dataset.x==="day")fday=null;else if(x.dataset.x==="cat")fcat=null;else{fday=null;fcat=null}render()});
document.querySelectorAll("[data-t]").forEach(function(b){b.addEventListener("click",function(){mtype=b.dataset.t;document.querySelectorAll("[data-t]").forEach(function(x){x.setAttribute("aria-pressed",x===b)});fillCat()})});
$("bAdd").addEventListener("click",addManual);$("md").value=today();fillCat();
$("pend").addEventListener("click",function(e){var c=e.target.closest(".cpm");if(c){copyPend(+c.dataset.i);return}var x=e.target.closest("li.sub[data-k]");if(x)jumpTo(x.dataset.k)});
$("pend").addEventListener("keydown",function(e){var x=e.target.closest&&e.target.closest("li.sub[data-k]");if(x&&(e.key==="Enter"||e.key===" ")){e.preventDefault();jumpTo(x.dataset.k)}});
$("sync").addEventListener("click",function(e){if(e.target.closest(".go"))openBox("impbox")});
$("catman").addEventListener("input",function(e){var t=e.target,r=t.closest&&t.closest(".crow");if(!r||!cdr)return;var x=cdr.list[+r.dataset.i];if(!x)return;if(t.classList.contains("cn"))x.n=t.value;else if(t.classList.contains("ck"))x.kwt=t.value;else if(t.classList.contains("cc"))x.c=t.value;else if(t.classList.contains("cbud"))x.b=t.value});
$("catman").addEventListener("change",function(e){var t=e.target;if(!cdr)return;if(t.classList.contains("ct")){var r=t.closest(".crow");if(r&&cdr.list[+r.dataset.i])cdr.list[+r.dataset.i].inc=t.value==="in"}else if(t.classList.contains("cdt"))cdr.delTo=t.value});
$("catman").addEventListener("click",function(e){var b=e.target.closest("button");if(!b||!cdr)return;var r=b.closest(".crow"),x=r?cdr.list[+r.dataset.i]:null;
 if(b.classList.contains("cadd")){var used={};cdr.list.forEach(function(y){used[String(y.c).toLowerCase()]=1});var colr=PAL.filter(function(c){return!used[c.toLowerCase()]})[0]||PAL[cdr.list.length%PAL.length],i0=cdr.list.findIndex(function(y){return y.sys}),pos=i0<0?cdr.list.length:i0;
  cdr.list.splice(pos,0,{id:"c-"+Math.random().toString(36).slice(2,8),n:"",c:colr,inc:0,custom:1,kw:[],kwt:""});renderCatMan();setTimeout(function(){var n=$("catman").querySelector('.crow[data-i="'+pos+'"] .cn');if(n&&n.focus)n.focus()},0)}
 else if(b.classList.contains("cdel")&&x){cdr.delId=x.id;cdr.delTo="Otros";renderCatMan()}
 else if(b.classList.contains("cdx")){cdr.delId=null;renderCatMan()}
 else if(b.classList.contains("cdc")){var id=cdr.delId,to=cdr.delTo;if(!id||!to)return;cdr.list=cdr.list.filter(function(y){return y.id!==id});Object.keys(cdr.redir).forEach(function(k){if(cdr.redir[k]===id)cdr.redir[k]=to});cdr.redir[id]=to;cdr.delId=null;renderCatMan()}
 else if(b.classList.contains("crs")){BASE.forEach(function(bb){if(!cdr.list.some(function(y){return y.id===bb.id})){var y=cl(bb);y.kwt=(y.kw||[]).join(", ");var i1=cdr.list.findIndex(function(z){return z.id==="Otros"});cdr.list.splice(i1<0?cdr.list.length:i1,0,y);delete cdr.redir[bb.id]}});renderCatMan()}
 else if(b.classList.contains("csave"))saveCats();
 else if(b.classList.contains("cdis")){cdr=null;renderCatMan();toast("Cambios descartados")}});
$("bRev").addEventListener("click",review);
$("bClr").addEventListener("click",function(){$("paste").value="";$("prev").innerHTML="";pv=null;pvDel=null;try{$("photof").value=""}catch(e){}if(!$("photoctl").hidden)$("photomsg").textContent="";toast("Importación limpiada");$("paste").focus()});$("prev").addEventListener("click",function(e){if(e.target.id==="bSave")save()});$("prev").addEventListener("change",function(e){if(e.target.id==="incDel")updSave()});$("bExp").addEventListener("click",exportCsv);
function banner(t){var b=$("banner");b.textContent=t;b.hidden=false;$("bRev").disabled=true;$("bAdd").disabled=true}
function setHide(v){hide=v;try{localStorage.setItem("gastos_hide",v?"1":"0")}catch(e){}var b=$("bHide");b.textContent=v?"🙈":"👁";b.title=v?"Mostrar importes":"Ocultar importes";b.setAttribute("aria-label",b.title);b.setAttribute("aria-pressed",v);$("bExp").disabled=v;$("bBak").disabled=v;
 if(v){$("paste").value="";$("prev").innerHTML="";pv=null;pvDel=null;closeBox("impbox");closeBox("addbox");ed=null;pick=null}render()}
$("bHide").addEventListener("click",function(){setHide(!hide)});
try{hide=localStorage.getItem("gastos_hide")==="1"}catch(e){}
setHide(hide);
(function(){
var docsMem={},cbSnap=null,mode="",LSK="mis-gastos-datos-v1";
function emitSnap(){if(cbSnap)cbSnap({docs:Object.keys(docsMem).map(function(id){return{id:id,data:function(){return JSON.parse(JSON.stringify(docsMem[id]))}}})});if(mode==="local"&&typeof backupReminder==="function")backupReminder()}
/* Modo demostracion: se cambian los datos y el "coll" por unos en memoria; al salir se restauran los reales, que nunca se tocan. */
var demoSave=null;
function demoStart(){if(demoSave)return tourInfo;var d=demoDocs();demoSave={docs:docsMem,coll:coll};docsMem=d.docs;demoMode=true;
 coll={doc:function(id){return{set:async function(v){docsMem[id]=JSON.parse(JSON.stringify(v));emitSnap()}}},onSnapshot:function(cb){cbSnap=cb;emitSnap()}};
 $("demobar").hidden=false;sel=d.info.selKey;filter="all";q="";$("q").value="";fday=null;fcat=null;editing=null;ed=null;pick=null;emitSnap();return d.info}
function demoEnd(){if(!demoSave)return;docsMem=demoSave.docs;coll=demoSave.coll;demoSave=null;demoMode=false;$("demobar").hidden=true;
 sel=null;filter="all";q="";$("q").value="";fday=null;fcat=null;editing=null;ed=null;pick=null;pv=null;pvDel=null;$("paste").value="";$("prev").innerHTML="";emitSnap()}
demoApi.start=demoStart;demoApi.end=demoEnd;$("demoExit").addEventListener("click",function(){tourStop()});
function lsSave(){localStorage.setItem(LSK,JSON.stringify({docs:docsMem}))}
async function api(path,opt){opt=opt||{};opt.headers=Object.assign({"X-Gastos":"1"},opt.headers||{});opt.cache="no-store";var r=await fetch(path,opt);if(!r.ok)throw new Error("HTTP "+r.status);return r.json()}
function infoBanner(x){var b=$("banner");b.textContent=x;b.hidden=false;b.className="banner info"}
function onSnap(snap){months={};rules={};links={};shared={};deleted={};excl={};meta={};catsDoc=null;prefsDoc=null;iaDoc=null;learnDoc=null;snap.docs.forEach(function(d){var v=d.data()||{};if(d.id==="rules")rules=v.map||{};else if(d.id==="links")links=v.map||{};else if(d.id==="shared")shared=v.map||{};else if(d.id==="deleted")deleted=v.map||{};else if(d.id==="excl")excl=v.map||{};else if(d.id==="meta")meta=v;else if(d.id==="cats")catsDoc=v;else if(d.id==="prefs")prefsDoc=v;else if(d.id==="ia")iaDoc=v;else if(d.id==="learn")learnDoc=v;else if(d.id.indexOf("m-")===0)months[d.id.slice(2)]=v.items||[]});applyCats();fillCat();ready=true;render()}
function backupReminder(){var bar=$("bakbar");if(!bar)return;if(demoMode||mode!=="local"){bar.hidden=true;return}
 var has=Object.keys(docsMem).some(function(k){return k.indexOf("m-")===0});if(!has){bar.hidden=true;return}
 var last=0,first=0,snooze=0;try{last=+localStorage.getItem("gastos_lastbak")||0;snooze=+localStorage.getItem("gastos_snooze")||0;first=+localStorage.getItem("gastos_firstuse")||0;if(!first){first=Date.now();localStorage.setItem("gastos_firstuse",String(first))}}catch(e){}
 var days=Math.floor((Date.now()-(last||first))/864e5);
 if(days>=7&&Date.now()>snooze){$("bakmsg").textContent=(last?"Hace "+days+" días que no descargas una copia de seguridad.":"Aún no has descargado ninguna copia de seguridad.")+" Tus datos están solo en este navegador.";bar.hidden=false}else bar.hidden=true}
async function backup(){if(demoMode){toast("En la demostración no se pueden descargar copias");return}try{localStorage.setItem("gastos_lastbak",String(Date.now()))}catch(e){}if($("bakbar"))$("bakbar").hidden=true;download("mis-gastos-copia-"+today()+".json",JSON.stringify({app:"mis-gastos",version:1,exported:new Date().toISOString(),docs:docsMem},null,1),"application/json");toast("Copia descargada")}
async function restore(f){if(demoMode){toast("En la demostración no se pueden restaurar copias");return}try{var j=JSON.parse(await f.text()),d=j&&j.docs;if(!d||typeof d!=="object"||Array.isArray(d))throw 0;
 if(!confirm("Esto reemplazará todos los datos actuales por los de la copia ("+Object.keys(d).length+" bloques). ¿Continuar?"))return;
 if(mode==="server")await api("api/restore",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({docs:d})});
 docsMem=d;if(mode==="local")lsSave();emitSnap();toast("Copia restaurada")}catch(e){toast("El archivo no es una copia válida")}}
/* Convierte las lineas que devuelve el OCR (con posicion de cada palabra) en el texto
   estandar "nombre / fecha - estado / importe" que ya entiende el importador. */
var OCR_MON={ene:1,feb:2,mar:3,abr:4,may:5,jun:6,jul:7,ago:8,sep:9,set:9,oct:10,nov:11,dic:12};
function ocrAmount(s){
  var m=/^(.*?)\s*([+\-\u2212\u2013])?\s*(\d{1,3}(?:[.\s]\d{3})*[,.]\d{2})\s*(?:[\u20acEeCc\u00a3&]|EUR|eur)?\s*$/.exec(s);
  if(!m) return null;
  var num=m[3].replace(/\s/g,"");
  if(/,\d{2}$/.test(num)) num=num.replace(/\./g,"");
  var v=parseFloat(num.replace(",","."));
  if(isNaN(v)) return null;
  return {rest:(m[1]||"").trim(),sign:m[2]&&"+"===m[2]?"+":"-",value:v};
}
function ocrDate(s){
  var rel=/^(hoy|ayer|anteayer)\b\s*(?:[-·•.:*|~]+\s*)?(.*)$/i.exec(s.trim());
  if(rel){var rd=new Date(),bk=/^hoy/i.test(rel[1])?0:(/^ayer/i.test(rel[1])?1:2);rd.setDate(rd.getDate()-bk);
    return {day:rd.getDate(),mon:rd.getMonth()+1,status:(rel[2]||"").replace(/[\s\-·•.:*|~]+$/,"").trim()};}
  // formato numerico "31/8", "29/8 - Bizum", "5/10/2026"
  var n=/^([0-9OIl|T]{1,2})\s*[\/\\|]\s*([0-9OIl|]{1,2})(?:\s*[\/\\|]\s*(\d{2,4}))?(?!\d)\s*(?:[-·•.:*|~]+\s*|\s+)?(.*)$/.exec(s.trim());
  if(n){
    var fx=function(t){return parseInt(t.replace(/[Il|T]/g,"1").replace(/O/g,"0"),10)},nd=fx(n[1]),nm=fx(n[2]);
    if(nm>12&&n[2].length===2) nm=fx(n[2].charAt(1));   /* "31/77" -> 31/7 */
    if(nd>=1&&nd<=31&&nm>=1&&nm<=12)
      return {day:nd,mon:nm,status:(n[4]||"").replace(/^[\s\-·•.:*|~]+/,"").replace(/[\s\-·•.:*|~]+$/,"").trim()};
  }
  var m=/^([0-9OIl|T]{1,2})\s*([A-Za-z0-9\u00f1]{3,10})\.?\s*(?:[-\u00b7\u2022.:*|~]+\s*|\s+)?(.*)$/.exec(s.trim());
  if(!m) return null;
  var dd=m[1].replace(/[Il|T]/g,"1").replace(/O/g,"0"), day=parseInt(dd,10);
  if(!(day>=1&&day<=31)) return null;
  var tok=m[2].toLowerCase().replace(/0/g,"o").replace(/1/g,"l").replace(/5/g,"s");
  var mon=OCR_MON[tok.slice(0,3)];
  if(!mon) return null;
  var status=(m[3]||"").replace(/^[\s\-\u00b7\u2022.:*|~]+/,"").replace(/[\s\-\u00b7\u2022.:*|~]+$/,"").trim();
  return {day:day,mon:mon,status:status};
}
function ocrKey(name,d,amt){return name.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/\s+/g," ").trim()+"|"+d.day+"/"+d.mon+"|"+String(d.status||"").toLowerCase()+"|"+amt}
function fmtEur(sign,v){var s=v.toFixed(2).replace(".",",").replace(/\B(?=(\d{3})+(?!\d))/g,function(){return""});return (sign==="+"?"+":"")+s+" \u20ac"}
var OCR_ST=["Bizum","Completada","Enviado","Rechazada","Verificaci\u00f3n de tarjeta"];
function ocrLev(a,b){var p=[],i,j;for(j=0;j<=b.length;j++)p[j]=j;for(i=1;i<=a.length;i++){var q=[i];for(j=1;j<=b.length;j++)q[j]=Math.min(p[j]+1,q[j-1]+1,p[j-1]+(a[i-1]===b[j-1]?0:1));p=q}return p[b.length]}
/* corrige el estado leido ("inn", "Bey"... -> "Bizum") comparando con los estados conocidos */
function ocrStatus(s){
  s=String(s||"").trim(); if(!s) return "";
  var n=s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z ]/g,""),best=null,bd=99;
  OCR_ST.forEach(function(k){var kn=k.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g,""),d=Math.min(ocrLev(n,kn),ocrLev(n,kn.slice(0,n.length)));if(d<bd){bd=d;best=k}});
  if(best&&bd<=Math.ceil(best.length*0.4)) return best;
  if(n.length<=4) return "Bizum";   /* el estado corto mas habitual; se ve en la revision antes de guardar */
  return s;
}
function ocrHeader(t){
  var w=t.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z ]/g,"").trim();
  if(!w||w.indexOf(" ")>-1) return false;
  return ["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"].some(function(m){return ocrLev(w,m)<=1});
}
/* Columna donde empieza el texto de los movimientos (inicio de las lineas de fecha) */
function ocrTextX(lines){
  var xs=[];
  lines.forEach(function(l){if(l.words&&l.words.length&&ocrDate(l.text||"")) xs.push(l.words[0].x0)});
  xs.sort(function(a,b){return a-b});
  return xs.length?xs[Math.floor(xs.length/2)]:null;
}
function ocrToText(lines){
  var x0=ocrTextX(lines);
  var rows=lines.map(function(l){
    var txt=l.text||"";
    if(x0!==null&&l.words&&l.words.length){
      var keep=l.words.filter(function(w){return w.x1>=x0-8});
      txt=keep.map(function(w){return w.text}).join(" ");
    }
    txt=txt.replace(/\s+/g," ").trim();
    if(!txt) return {t:"x",raw:""};
    var d=ocrDate(txt); if(d) return {t:"d",d:d,raw:txt};
    var a=ocrAmount(txt);
    if(a&&a.rest&&/[A-Za-z\u00c0-\u00ff]{2}/.test(a.rest)) return {t:"na",name:a.rest.replace(/^[^A-Za-z0-9\u00c0-\u00ff]+/,"").trim(),a:a,raw:txt};
    if(a&&!/[A-Za-z\u00c0-\u00ff]{2}/.test(a.rest)) return {t:"a",a:a,raw:txt};
    if(/[A-Za-z\u00c0-\u00ff]{2}/.test(txt)&&!ocrHeader(txt)) return {t:"n",name:txt.replace(/^[^A-Za-z0-9\u00c0-\u00ff]+/,"").trim(),raw:txt};
    return {t:"x",raw:txt};
  });
  /* Maquina de estados: un movimiento = nombre + importe + fecha, en cualquier orden.
     (en algunas capturas el importe va centrado entre el nombre y la fecha y el OCR lo saca en otra linea) */
  var items=[],orph=[],cur={};
  function flush(){
    if(cur.a&&cur.d){
      var am=fmtEur(cur.a.sign,cur.a.value),st=ocrStatus(cur.d.status),nm=cur.name||"(nombre ilegible)";
      items.push({key:ocrKey(nm,{day:cur.d.day,mon:cur.d.mon,status:st},am),text:nm+"\n"+cur.d.day+"/"+cur.d.mon+(st?" - "+st:"")+"\n"+am});
    } else if(cur.name&&cur.a) orph.push(cur.name+" "+fmtEur(cur.a.sign,cur.a.value));
    cur={};
  }
  /* un movimiento = nombre + importe + fecha; la fecha lo cierra. El importe puede ir en la misma linea que el nombre
     o (capturas con el importe centrado) en una linea propia entre el nombre y la fecha. */
  rows.forEach(function(r){
    if(r.t==="n"){
      if(cur.name&&cur.a) flush();
      cur.name=cur.name?cur.name+" "+r.name:r.name;
    } else if(r.t==="na"){
      if(cur.name||cur.a) flush();
      cur.name=r.name;cur.a=r.a;
    } else if(r.t==="a"){
      if(cur.a) flush();
      cur.a=r.a;
    } else if(r.t==="d"){
      cur.d=r.d;flush();
    }
  });
  flush();
  var text=items.map(function(x){return x.text}).concat(orph.map(function(o){return"\u26a0 sin fecha reconocida: "+o})).join("\n\n");
  return {text:text,count:items.length,items:items,orphans:orph};
}
/* Detecta las lineas de texto de la imagen binaria (negro = tinta) en cada columna: la del texto (nombre y fecha) y
   la de los importes (a la derecha, separada por un hueco grande). Devuelve rectangulos para leer cada linea por separado. */
function ocrBands(g,w,h,xt){
  var xs=Math.max(0,Math.round(xt-10)),col=new Int32Array(w),x,y;
  for(y=0;y<h;y++)for(x=xs;x<w;x++)if(g[y*w+x]===0)col[x]++;
  var first=-1,last=-1;for(x=xs;x<w;x++)if(col[x]){if(first<0)first=x;last=x}
  if(first<0) return [];
  var gs=-1,gl=0,run=0;
  for(x=first;x<=last;x++){if(!col[x]){run++}else{if(run>gl){gl=run;gs=x-run}run=0}}
  var cols=(gl>=w*0.05)?[[xs,gs,"t"],[gs+gl,w,"a"]]:[[xs,w,"t"]],out=[];
  cols.forEach(function(c){
    var cx0=c[0],cx1=c[1],runs=[],st=-1;
    for(y=0;y<=h;y++){
      var ink=0;if(y<h)for(x=cx0;x<cx1;x++)if(g[y*w+x]===0){ink=1;break}
      if(ink&&st<0)st=y;else if(!ink&&st>=0){runs.push([st,y-1]);st=-1}
    }
    var hs=runs.map(function(r){return r[1]-r[0]+1}).sort(function(a,b){return a-b}),mh=hs.length?hs[Math.floor(hs.length/2)]:0;
    if(!mh) return;
    var merged=[];runs.forEach(function(r){var l=merged[merged.length-1];if(l&&r[0]-l[1]-1<=Math.max(2,Math.round(mh*0.15)))l[1]=r[1];else merged.push([r[0],r[1]])});
    merged.forEach(function(r){
      if(r[1]-r[0]+1<mh*0.4) return;
      var bx0=cx1,bx1=cx0;for(y=r[0];y<=r[1];y++)for(x=cx0;x<cx1;x++)if(g[y*w+x]===0){if(x<bx0)bx0=x;if(x>bx1)bx1=x}
      if(bx1<bx0) return;
      var pad=Math.max(6,Math.round(mh*0.5));
      out.push({col:c[2],y:(r[0]+r[1])/2,left:Math.max(0,bx0-pad),top:Math.max(0,r[0]-pad),width:Math.min(w,bx1+pad+1)-Math.max(0,bx0-pad),height:Math.min(h,r[1]+pad+1)-Math.max(0,r[0]-pad)});
    });
  });
  out.sort(function(a,b){return a.y-b.y});
  return out;
}
/* Une varias capturas que se solapan (o que son la misma): quita la zona comun una sola vez.
   Los movimientos identicos que NO estan en la zona comun se conservan (pueden ser pagos repetidos de verdad). */
function mergeShots(list){
  var all=list.length?list[0].slice():[];
  for(var i=1;i<list.length;i++){
    var b=list[i],kmax=Math.min(all.length,b.length),fwd=0,rev=0,k,j,ok;
    for(k=kmax;k>0;k--){ok=true;for(j=0;j<k;j++){if(all[all.length-k+j].key!==b[j].key){ok=false;break}}if(ok){fwd=k;break}}
    for(k=kmax;k>0;k--){ok=true;for(j=0;j<k;j++){if(all[j].key!==b[b.length-k+j].key){ok=false;break}}if(ok){rev=k;break}}
    if(fwd>=rev) all=all.concat(b.slice(fwd));
    else all=b.slice(0,b.length-rev).concat(all);
  }
  return all;
}

var ocrW=null;
function loadScript(src){return new Promise(function(ok,ko){var s=document.createElement("script");s.src=src;s.onload=ok;s.onerror=function(){ko(new Error("no se pudo cargar "+src))};document.head.appendChild(s)})}
async function getWorker(onProg){if(ocrW)return ocrW;if(!window.Tesseract)await loadScript("ocr/tesseract.min.js");
 var abs=function(p){return new URL(p,location.href).href.replace(/\/$/,"")};
 ocrW=await Tesseract.createWorker("spa",1,{workerPath:abs("ocr/worker.min.js"),corePath:abs("ocr/core"),langPath:abs("ocr/lang"),gzip:true,logger:function(m){if(onProg)onProg(m)}});
 await ocrW.setParameters({tessedit_pageseg_mode:"6",preserve_interword_spaces:"1"});return ocrW}
async function prepImage(file){var url=URL.createObjectURL(file);
 var img=await new Promise(function(ok,ko){var i=new Image();i.onload=function(){ok(i)};i.onerror=function(){ko(new Error("imagen no valida"))};i.src=url});
 var w=img.naturalWidth,h=img.naturalHeight,sc=w<1000?3:(w>1800?1800/w:1),cw=Math.round(w*sc),ch=Math.round(h*sc),cv=document.createElement("canvas");cv.width=cw;cv.height=ch;
 var cx=cv.getContext("2d");cx.drawImage(img,0,0,cw,ch);URL.revokeObjectURL(url);
 var d=cx.getImageData(0,0,cw,ch),px=d.data,n=cw*ch,g=new Uint8Array(n),hist=new Array(256).fill(0),i,j;
 for(i=0,j=0;i<n;i++,j+=4){var v=(px[j]*299+px[j+1]*587+px[j+2]*114)/1000|0;g[i]=v;hist[v]++}
 var bg=0,mx=0;for(var k=0;k<256;k++)if(hist[k]>mx){mx=hist[k];bg=k}
 for(i=0,j=0;i<n;i++,j+=4){var o=Math.abs(g[i]-bg)>30?0:255;px[j]=px[j+1]=px[j+2]=o;px[j+3]=255}
 cx.putImageData(d,0,0);return cv}
function ocrLines(d){var out=[];(d.blocks||[]).forEach(function(b){(b.paragraphs||[]).forEach(function(p){(p.lines||[]).forEach(function(l){
  var ws=(l.words||[]).map(function(w){return{text:w.text,x0:w.bbox.x0,x1:w.bbox.x1,y0:w.bbox.y0}});
  if(ws.length)out.push({text:ws.map(function(w){return w.text}).join(" "),words:ws,y0:Math.min.apply(null,ws.map(function(w){return w.y0}))})})})});
 if(!out.length&&d.text)d.text.split("\n").forEach(function(t,i){if(t.trim())out.push({text:t.trim(),words:[],y0:i})});
 out.sort(function(a,b){return a.y0-b.y0});return out}
async function readPhotos(){var f=$("photof").files,m=$("photomsg"),b=$("bPhoto");
 if(!f||!f.length){m.textContent="Elige primero una o varias fotos.";return}
 b.disabled=true;
 try{m.textContent="Cargando el lector de texto (la primera vez tarda unos segundos)…";
  var w=await getWorker(function(p){if(p&&p.status==="recognizing text")m.textContent="Leyendo… "+Math.round((p.progress||0)*100)+"%"});
  var shots=[],orph=[];
  for(var i=0;i<f.length;i++){var lbl="Leyendo la foto "+(i+1)+" de "+f.length+"…";m.textContent=lbl;
   var cv=await prepImage(f[i]);await w.setParameters({tessedit_pageseg_mode:"6"});
   var r=await w.recognize(cv,{},{blocks:true}),l1=ocrLines(r.data),o=ocrToText(l1),xt=ocrTextX(l1);
   if(xt!==null){
    /* 2o metodo: se localiza cada linea de texto por columnas (nombre/fecha | importe) y se lee suelta; es mucho mas fiable
       que leer la pagina entera cuando hay iconos o el importe va centrado entre el nombre y la fecha */
    var cw=cv.width,ch=cv.height,px=cv.getContext("2d").getImageData(0,0,cw,ch).data,g=new Uint8Array(cw*ch),q;
    for(q=0;q<cw*ch;q++)g[q]=px[q*4]>128?255:0;
    var bands=ocrBands(g,cw,ch,xt),lines=[],tc=document.createElement("canvas"),tx=tc.getContext("2d");
    for(var k=0;k<bands.length;k++){
     var bd=bands[k];m.textContent=lbl+" (línea "+(k+1)+"/"+bands.length+")";
     tc.width=bd.width;tc.height=bd.height;tx.fillStyle="#fff";tx.fillRect(0,0,bd.width,bd.height);tx.drawImage(cv,bd.left,bd.top,bd.width,bd.height,0,0,bd.width,bd.height);
     await w.setParameters({tessedit_pageseg_mode:"7"});
     var t=((await w.recognize(tc)).data.text||"").replace(/\s+/g," ").trim();
     if(!t){await w.setParameters({tessedit_pageseg_mode:"13"});t=((await w.recognize(tc)).data.text||"").replace(/\s+/g," ").trim()}
     lines.push({text:t,words:[],y0:bd.y})}
    var ob=ocrToText(lines);if(ob.count>=o.count)o=ob}
   shots.push(o.items);o.orphans.forEach(function(x){if(orph.indexOf(x)<0)orph.push(x)})}
  var merged=mergeShots(shots),total=merged.length,txt=merged.map(function(x){return x.text}).concat(orph.map(function(x){return"\u26a0 sin fecha reconocida: "+x})).join("\n\n");
  if(!txt){m.textContent="No he reconocido ningún movimiento. Prueba con una captura de pantalla nítida de la lista (mejor que una foto a la pantalla).";return}
  $("paste").value=txt;
  m.textContent="Leídos "+total+" movimientos"+(orph.length?" (y "+orph.length+" sin fecha, marcados con ⚠ en el texto)":"")+". Revisa lo leído y pulsa Guardar. Si ves alguna cifra mal, corrígela en el cuadro de texto y vuelve a pulsar «Revisar».";
  await review()}
 catch(e){console.error(e);m.textContent="No se han podido leer las fotos ("+(e&&e.message?e.message:String(e)).slice(0,120)+"). Inténtalo de nuevo o pega el texto."}
 finally{b.disabled=false}}
$("bPhoto").addEventListener("click",readPhotos);
/* ===== Pegar una captura directamente (sin guardarla como archivo) ===== */
function addPics(fs){if(!fs.length)return;var m=$("photomsg");if($("bPhoto").disabled){m.textContent="Espera a que termine de leer la captura anterior.";return}
 var dt=new DataTransfer(),cur=$("photof").files,i;for(i=0;i<cur.length;i++)dt.items.add(cur[i]);
 fs.forEach(function(f){dt.items.add(new File([f],"captura-"+(dt.files.length+1)+".png",{type:f.type||"image/png"}))});$("photof").files=dt.files;readPhotos()}
document.addEventListener("paste",function(e){if(!$("impbox").open||$("photoctl").hidden)return;var fs=Array.prototype.filter.call((e.clipboardData&&e.clipboardData.files)||[],function(f){return/^image\//.test(f.type)});if(!fs.length)return;e.preventDefault();addPics(fs)});
$("bPastePic").addEventListener("click",async function(){var m=$("photomsg");
 try{var items=await navigator.clipboard.read(),fs=[];for(var k=0;k<items.length;k++){var t=items[k].types.filter(function(x){return/^image\//.test(x)})[0];if(t)fs.push(await items[k].getType(t))}
  if(!fs.length){m.textContent="No hay ninguna imagen copiada. Haz la captura con Win + Mayús + S (se copia sola) y vuelve a pulsar este botón, o pulsa Ctrl + V.";return}
  addPics(fs)}catch(e){m.textContent="No he podido leer el portapapeles. Con esta ventana abierta, pulsa Ctrl + V para pegar la captura."}});


$("bBak").addEventListener("click",backup);$("bakNow").addEventListener("click",backup);$("bakLater").addEventListener("click",function(){try{localStorage.setItem("gastos_snooze",String(Date.now()+864e5))}catch(e){}$("bakbar").hidden=true});
$("bRes").addEventListener("change",function(e){var f=e.target.files&&e.target.files[0];if(f)restore(f);e.target.value=""});
/* ===== Version, actualizaciones y uso desde varios ordenadores ===== */
var verInfo={v:""},otroDismiss="",extBusy=false,updDismissed="";
async function updCheck(manual,auto){
 try{var r=await api("api/actualizacion/buscar",{method:"POST"});verInfo.v=r.actual||verInfo.v;
  if(!r.configurado){if(manual)toast("Las actualizaciones no están configuradas en esta copia");return}
  if(r.error){if(manual)toast(r.error);return}
  try{localStorage.setItem("gastos_updchk",String(Date.now()))}catch(e){}
  if(r.nueva){if(auto&&updDismissed===r.nueva)return;   /* dijo «Más tarde» en esta sesion: no insistir hasta que vuelva a abrirla */
   showUpd(r.nueva,r.notas)}
  else if(manual)toast("Estás al día: versión "+r.actual)}
 catch(e){if(manual)toast("No se han podido buscar actualizaciones")}}
function showUpd(v,notas){$("updLater").textContent="Más tarde";$("updmsg").innerHTML="Hay una versión nueva de Mis gastos (<b>"+esc(v)+"</b>)."+(notas?" "+esc(notas):"");$("updbar").dataset.v=v;$("updNow").hidden=false;$("updNow").disabled=false;$("updLater").hidden=false;$("updbar").hidden=false}
function showNovedad(a,v){var key=a+">"+v;try{if(localStorage.getItem("gastos_novedad")===key)return;localStorage.setItem("gastos_novedad",key)}catch(e){}
 $("updmsg").innerHTML="✅ Mis gastos se ha actualizado de la versión "+esc(a)+" a la <b>"+esc(v)+"</b>. Tus datos siguen igual.";$("updbar").dataset.v="";$("updNow").hidden=true;$("updLater").textContent="Entendido";$("updLater").hidden=false;$("updbar").hidden=false}
async function updInstall(){var b=$("updNow");b.disabled=true;$("updLater").hidden=true;$("updmsg").innerHTML='<span class="spin" aria-hidden="true"></span> Actualizando… no cierres la ventana.';
 try{var resp=await fetch("api/actualizacion/instalar",{method:"POST",headers:{"X-Gastos":"1"},cache:"no-store"}),r=await resp.json();if(!resp.ok)throw new Error(r.error||"No se ha podido actualizar");
  var t0=Date.now();
  for(;;){await new Promise(function(ok){setTimeout(ok,800)});
   if(Date.now()-t0>30000){$("updmsg").textContent="Actualizado. Cierra la ventana y ábrela de nuevo con «Mis gastos».";b.hidden=true;return}
   try{var h=await(await fetch("api/hola",{cache:"no-store"})).json();if(h&&h.version===r.version){location.reload();return}}catch(e){}}}
 catch(e){b.disabled=false;b.hidden=false;$("updLater").hidden=false;$("updmsg").textContent=(e&&e.message)||"No se ha podido actualizar. Inténtalo más tarde."}}
$("updNow").addEventListener("click",updInstall);$("updLater").addEventListener("click",function(){var v=$("updbar").dataset.v;if(v)updDismissed=v;$("updbar").hidden=true});$("bUpd").addEventListener("click",function(){updCheck(true)});
function showOtro(n){var bar=$("otrobar");if(!n.length){bar.hidden=true;otroDismiss="";return}var key=n.join(",");if(key===otroDismiss)return;
 $("otromsg").textContent="Parece que «Mis gastos» también está abierta en otro ordenador ("+n.join(", ")+"). Si usas las dos a la vez, los cambios de una pueden pisar los de la otra: cierra una de las dos o espera a que Drive termine de sincronizar.";bar.dataset.k=key;bar.hidden=false}
$("otroOk").addEventListener("click",function(){otroDismiss=$("otrobar").dataset.k||"";$("otrobar").hidden=true});
function refreshExt(){if(extBusy||demoMode)return;extBusy=true;api("api/data").then(function(j){docsMem=j.docs||{};emitSnap();toast("Datos actualizados desde otro ordenador")}).catch(function(){}).then(function(){extBusy=false})}
(async function(){
 try{
  if(location.protocol!=="file:"){try{var j=await api("api/data");docsMem=j.docs||{};mode="server"}catch(e){mode=""}}
  if(!mode){mode="local";try{var raw=localStorage.getItem(LSK);docsMem=raw?(JSON.parse(raw).docs||{}):{}}catch(e){docsMem={}}}
  coll={doc:function(id){return{set:async function(d){var c=JSON.parse(JSON.stringify(d));
    if(mode==="server")await api("api/doc/"+encodeURIComponent(id),{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(c)});
    var prev=docsMem[id];docsMem[id]=c;if(mode==="local"){try{lsSave()}catch(e){if(prev===undefined)delete docsMem[id];else docsMem[id]=prev;throw e}}
    emitSnap()}}},onSnapshot:function(cb){cbSnap=cb;emitSnap()}};
  appPhotos=mode==="server";$("photoctl").hidden=!appPhotos;$("photobox").hidden=!appPhotos;
  if(mode!=="server"&&location.protocol!=="file:"){fetch("ocr/worker.min.js",{method:"HEAD",cache:"no-store"}).then(function(r){if(r.ok){appPhotos=true;$("photoctl").hidden=false;$("photobox").hidden=false}}).catch(function(){})}
  iaInit(mode==="server");
  if(mode==="server"){   /* avisa al servidor de que la ventana sigue abierta; al cerrarla, el servidor se apaga solo */
   var tid=Math.random().toString(36).slice(2),bad=0,hdr={"X-Gastos":"1"},pg=function(){fetch("api/ping?id="+tid,{method:"POST",headers:hdr,cache:"no-store"}).then(function(r){if(r.status===404)return null;if(!r.ok)throw 0;bad=0;return r.json()}).then(function(j){if(!j)return;if(j.cambio)refreshExt();showOtro(j.otro||[])}).catch(function(){if(++bad===3)infoBanner("La aplicación se ha cerrado (por ejemplo, tras suspender el ordenador). Ciérrala y ábrela de nuevo con «Mis gastos».")})};
   fetch("api/hola",{cache:"no-store"}).then(function(r){return r.json()}).then(function(h){if(h&&h.version){verInfo.v=h.version;$("verTxt").textContent="Versión "+h.version;$("bUpd").hidden=false;if(h.anterior)showNovedad(h.anterior,h.version)}}).catch(function(){});
   var updAuto=function(first){if(demoMode||tourOn)return;var last=0;try{last=+localStorage.getItem("gastos_updchk")||0}catch(e){}if(first||Date.now()-last>36e5)updCheck(false,true)};   /* siempre al abrir, y despues cada hora mientras siga abierta */
   setTimeout(function(){updAuto(true)},3000);setInterval(updAuto,36e5);
   pg();setInterval(pg,5000);window.addEventListener("pagehide",function(){try{fetch("api/adios?id="+tid,{method:"POST",headers:hdr,keepalive:true})}catch(e){}})}
  if(mode==="local"){try{if(navigator.storage&&navigator.storage.persist)navigator.storage.persist()}catch(e){}backupReminder()}
  $("stline").textContent=mode==="server"?"Tus datos se guardan en el archivo datos.json de la carpeta de la aplicación (con una copia diaria en la carpeta «copias»). No sale nada de este ordenador.":"Tus datos se guardan solo en este navegador, en este ordenador, y no salen de él. Descarga una copia de seguridad de vez en cuando (⚙ Ajustes → Descargar copia de seguridad)."
  coll.onSnapshot(onSnap);
  if(mode==="server")window.addEventListener("focus",function(){if(demoMode)return;api("api/data").then(function(j){docsMem=j.docs||{};emitSnap()}).catch(function(){})});
 }catch(e){banner("No se han podido cargar los datos.");ready=true;render()}
})();
})();
})();
